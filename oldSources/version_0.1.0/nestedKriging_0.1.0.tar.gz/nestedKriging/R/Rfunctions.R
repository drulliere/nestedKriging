


setNumThreadsBLAS <-function(numThreadsBLAS=1, showMessage=TRUE) {
  ##library(RhpcBLASctl)
  RhpcBLASctl::blas_set_num_threads(numThreadsBLAS)
  if (showMessage) {  message("linear algebra libray BLAS threads set to ", numThreadsBLAS) }
}

nestedKriging <- function(X, Y, clusters, x, covtype, param, sd2, krigingType="simple", tagAlgo = "", numThreadsPredPoints = 1L, numThreadsGroups = 16L, verboseDetails = 10L, outputDetailLevel = 0L, numThreadsBLAS = 1L, globalOptions= as.integer( c(0))) {

  ################################################### basic check of input arguments validity

  if (class(X)!="matrix") stop("X must be a matrix")
  if ((nrow(X)<1)||(ncol(X)<1)) stop("X must have at least one raw and one column")
  if (!is.numeric(X)) stop("X must contain numeric values")
  if (!all(is.finite(X))) stop("X must contain finite values")

  if(!is.numeric(Y)) stop("Y must be a vector of numeric values")
  if (length(Y)<1) stop("Y must contain at least one value")
  if (!all(is.finite(Y))) stop("Y must contain finite values")
  if(!(length(Y)==nrow(X))) stop("Y must have the same length as the number of rows in X")

  if (!is.numeric(clusters)) stop("clusters must be a vector of integer values")
  if (length(clusters)<1) stop("clusters must contain at least one value")
  if (!all(is.finite(clusters))) stop("clusters must contain finite values")
  if (!isTRUE(all.equal(clusters, as.integer(clusters)))) stop("clusters must contain integer values")
  if (!all(clusters>=0)) stop("clusters must contain nonnegative integer values")
  if (!(length(clusters)==nrow(X))) stop("clusters must have the same length as the number of rows in X")
  clusters <- as.integer(round(clusters,0))

  if (class(x)!="matrix") stop("x must be a matrix")
  if ((nrow(x)<1)||(ncol(x)<1)) stop("x must have at least one raw and one column")
  if (!is.numeric(x)) stop("x must contain numeric values")
  if (!all(is.finite(x))) stop("x must contain finite values")
  if (ncol(X)!=ncol(X)) stop("error: X and x must have the same number of columns")

  validCovType = c("gauss", "matern5_2", "matern3_2", "exp", "powexp", "white_noise")
  if(class(covtype)!="character") stop("covtype must be one of the following:", paste(validCovType, collapse=", ") )
  if(!(covtype) %in% validCovType) stop("covtype must be one of the following:", paste(validCovType, collapse=", ") )

  if(!is.numeric(param)) stop("param must be a vector of numeric values")
  if (!all(is.finite(param))) stop("param must contain finite values")
  if (length(param)<1) stop("param must contain at least one value")
  if(!(length(param)==ncol(X))) stop("param must have the same length as the number of columns in X")

  validKrigingType = c("simple", "ordinary")
  if(class(krigingType)!="character") stop("krigingType must be one of the following:", paste(validKrigingType, collapse=", ") )
  if(!(krigingType) %in% validKrigingType) stop("krigingType must be one of the following:", paste(validKrigingType, collapse=", ") )
  #if (!(is.logical(OrdinaryKriging))) stop("OrdinaryKriging must be a logical value, TRUE or FALSE")

  if (!(is.character(tagAlgo))) stop("tagAlgo must be a character string")

  integerList=list(numThreadsPredPoints, numThreadsGroups, numThreadsBLAS, verboseDetails, outputDetailLevel)
  integerListStr=list("numThreadsPredPoints", "numThreadsGroups", "numThreadsBLAS", "verboseDetails", "outputDetailLevel")
  for(i in 1:length(integerList)) {
    if (!(is.numeric(integerList[[i]]))) stop(integerListStr[[i]], " must be an integer numeric value")
    if (!(length(integerList[[i]])==1)) stop(integerListStr[[i]], " must be ONE integer")
    if (abs(integerList[[i]]-as.integer(integerList[[i]]))>1e-5) stop(integerListStr[[i]], " must be an integer")
  }

  numThreadsPredPoints <- as.integer(round(numThreadsPredPoints,0))
  numThreadsGroups <- as.integer(round(numThreadsGroups,0))
  numThreadsBLAS <- as.integer(round(numThreadsBLAS,0))
  verboseDetails <- as.integer(round(verboseDetails,0))
  outputDetailLevel <- as.integer(round(outputDetailLevel,0))

  if (numThreadsPredPoints<1) stop("numThreadsPredPoints must be at least 1")
  if (numThreadsGroups<1) stop("numThreadsGroups must be at least 1")
  if (numThreadsBLAS<1) stop("numThreadsBLAS must be at least 1")

  if(!is.numeric(globalOptions)) stop("globalOptions must be a vector of numeric values")
  if (length(globalOptions)<1) stop("globalOptions must contain at least one value")
  if (!all(is.finite(globalOptions))) stop("globalOptions must contain finite values")

  ################################################### Set BLAS Threads and launch algo

  setNumThreadsBLAS(numThreadsBLAS, FALSE)
  .Call('_nestedKriging_nestedKrigingDirect', PACKAGE = 'nestedKriging', X, Y, clusters, x, covtype, param, sd2, krigingType, tagAlgo, numThreadsPredPoints, numThreadsGroups, verboseDetails, outputDetailLevel, globalOptions)
}

