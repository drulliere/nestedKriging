
#ifndef TESTS_HPP
#define TESTS_HPP

#include "nestedKriging.h"

// [[Rcpp::plugins(openmp, cpp11)]]
using namespace Rcpp;

namespace nestedKrigTests {

using namespace nestedKrig;

//=================================================================================
//                        TEST FRAMEWORK
//=================================================================================

class Test {
  typedef std::string Context;
  typedef std::vector<Context> Contexts;

  const std::string testName;
  unsigned long sectionCounter, itemCounter;
  std::string sectionName, assertName;
  double precision, smallestValue;

  Contexts failureList;
  Contexts successList;

  Context getCompleteContext() const {
    std::ostringstream oss;
    oss << testCounter << "." << sectionCounter << "." << itemCounter << " " << testName << " " << sectionName << " " << assertName;
    return oss.str();
  }

  void appendToVector(Contexts& initialVector, const Contexts& addedVector) const {
    initialVector.insert(initialVector.end(), addedVector.begin(), addedVector.end());
  }

  double relativeError(double left, double right) const {
    if (fabs(left-right)<smallestValue) return 0;
    return fabs(left-right)/(fabs(left+right)+1e-100);
  }

  bool areClose(double left, double right) const {
    return relativeError(left,right)<precision;
  }

  void giveLeftRightDetails(double leftValue, double rightValue, std::string tag="") const {
    std::cout << std::setprecision(12) << "KO: " << getCompleteContext() << " left= " << leftValue << ", right= " << rightValue
              << ", error=" << relativeError(leftValue,rightValue) << " " << tag << std::endl;
  }

public:
  static unsigned long testCounter;

  Test(std::string testName) : testName(testName), sectionCounter(0), itemCounter(0),
                               sectionName(""), precision(1e-5), smallestValue(1e-100), failureList(0), successList(0) {
    ++testCounter;
  }

  Contexts getFailures() const {
    return failureList;
    }

  Contexts getSuccess() const {
    return successList;
    }

  bool status() const {
    return (failureList.size()==0);
  }

  void append(const Test& test) {
    //std::cout << "appending " << test.testName << std::endl;
    appendToVector(failureList, test.getFailures());
    appendToVector(successList, test.getSuccess());
  }

  void createSection(std::string sectionName) {
    this->sectionName = sectionName;
    ++sectionCounter;
    itemCounter=0;
  }

  void assertTrue(bool shouldBeTrue, std::string tag="") {
    assertName=tag;
    ++itemCounter;
    if (shouldBeTrue)
    successList.push_back(getCompleteContext());
    else
    failureList.push_back(getCompleteContext());
  }

  void setPrecision(double value, double smallestValue=1e-100) {
    precision = value;
    this->smallestValue = smallestValue;
  }

  void assertClose(const double& leftValue, const double& rightValue, std::string tag="") {
    assertName=tag;
    if (!areClose(leftValue,rightValue)) giveLeftRightDetails(leftValue, rightValue, tag);
    assertTrue(areClose(leftValue,rightValue), tag);
  }

  template <class VectorTypeL, class VectorTypeR>
  void assertCloseValues(const VectorTypeL left, const VectorTypeR right, std::string tag="") {
    assertName=tag;
    arma::mat leftV=arma::conv_to<arma::mat>::from(left), rightV=arma::conv_to<arma::mat>::from(right);
    bool close=((leftV.size()==rightV.size()) && (leftV.size()>0) && (rightV.size()>0));
    unsigned long sizeMin=std::min(leftV.size(), rightV.size());
    for(unsigned long i=0; i<sizeMin; ++i) {
        if (!areClose(leftV(i),rightV(i))) giveLeftRightDetails(leftV(i), rightV(i), tag + " item=" + std::to_string(i));
        close = close && areClose(leftV(i),rightV(i));
        }
    assertTrue(close, tag);
  }

  void printSummary(bool printSuccess=true) {
    std::size_t failures= failureList.size(), success= successList.size();
    std::cout << "------------- nested Kriging test suite ------------------" << std::endl;
    for(std::size_t i=0; i<success; ++i)
      if (printSuccess) std::cout << " ok: " << successList[i] << std::endl;
    std::cout << "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - " << std::endl;
    if (failures>0) std::cout << " ** WARNING ** WARNING ** WARNING **" << std::endl;
    std::cout << " failure ratio: " << failures << " / " << failures+success;
    if (failures==0)  {std::cout << " - SUCCESS";} else {std::cout << "- FAILURE"; }
    std::cout <<  std::endl;
    for(std::size_t i=0; i<failures; ++i)
      std::cout << " Failure: " << failureList[i] << std::endl;
    std::cout << "----------------------------------------------------------" << std::endl;
  }
};
unsigned long Test::testCounter = 0;

//==================================================== Part 0, Utilities for tests

//----------------------------------------------------------------------- Rng
// simple platform-free controlable random number generator, for test purposes
// do not change, since collected external case studies results depend on it
struct Rng {
  unsigned long long a, c, m, seed;

  explicit Rng(unsigned long long seed) : a(16807), c(0), m(2147483647), seed(seed) {}

  double operator()() {
    seed = (seed*a+c)%m;
    return static_cast<double>(seed)/static_cast<double>(m);
  }
};

//=================================================================================
//                        CASE STUDIES and ALGO CALL
//=================================================================================

class CaseStudy {

  bool createGpSize() {
    gpsize.set_size(N);
    gpsize.fill(0);
    for(arma::uword obs=0; obs<n; ++obs) ++gpsize(gp(obs)-1);
    unsigned long smallestSize=gpsize(0);
    for(arma::uword i=0; i<N; ++i) if (gpsize(i)<smallestSize) smallestSize=gpsize(i);
    return (smallestSize>0);
  }

  static arma::vec testFunction(arma::mat X){
    arma::vec resu(X.n_rows);
    double S=0;
    for(unsigned long i=0; i<X.n_rows; ++i) {
      for(unsigned long k=0; k<X.n_cols; ++k) S=S+sin(X(i,k)+S);
      resu[i]=S;
    }
    return resu;
  }
public:
  unsigned long seed, q, d, n, N, pickx;
  std::string covtype;
  double sd2;
  arma::mat X, x; arma::vec Y;
  arma::vec gp, param, gpsize;
  std::string tag;
  bool ordinaryKriging;

  CaseStudy() {}

  CaseStudy(long seed, std::string covtype, long largerDataFactor=1) {
    this->seed=seed;
    Rng rng(seed);
    bool goodExample;
    long factor=largerDataFactor;
    do {
      q=floor(rng()*10+2)*factor;
      d=floor(rng()*5)+2;
      n=(floor(rng()*64)+10)*factor;
      N=(floor(rng()*3)+4)*factor;
      ordinaryKriging=(rng()>0.5);
      this->covtype=covtype;
      sd2=rng()*4;
      x.set_size(q,d); x.imbue(rng); x=x*3-2;
      X.set_size(n,d); X.imbue(rng); X=sin(X)*10-6;
      param.set_size(d); param.imbue(rng); param=param*2+0.1+0.5;
      gp.set_size(n); gp.imbue(rng); gp=floor(gp*N)+1;
      pickx=floor(rng()*q);
      Y=testFunction(X);
      goodExample = createGpSize();
    }
    while (!goodExample);
  }

  void setSimpleKriging() {
    ordinaryKriging=false;
  }

  void setGroupsN_equals_1() { //change gp to one unique group
    gp.fill(1);
    gpsize.fill(0);
    gpsize(0)= n;
    N=1;
  }

  void setGroupsN_equals_n() { //change gp to one group per observation
    for(Long i=0; i<gp.size(); ++i) gp(i)=i;
    gpsize.fill(1);
    N=n;
  }

  void increaseLengthScalesBy(double value) {
    param = param + value;
  }

  void keepOnlyOneObservation(Long obs=0.0) {
    obs = obs % X.n_rows;
    arma::rowvec Xkept=X.row(obs); double Ykept=Y[obs];
    X.resize(1, d); X.row(0)=Xkept;
    Y.resize(1); Y[0]=Ykept;
    gp.resize(1); gp[0]=0;
    gpsize.resize(1); gpsize(0)=1;
  }

  void rotateObservations(Long shift=1) {
    const Long shiftByLines = 0; //contrary to what is indicated in Armadillo Library
    X = arma::shift(X, shift, shiftByLines);
    Y = arma::shift(Y, shift);
    gp = arma::shift(gp, shift);
  }

  void rotatePredPoints(Long shift=1) {
    const Long shiftByLines = 0; //contrary to what is indicated in Armadillo Library
    x = arma::shift(x, shift, shiftByLines);
  }

  void changeClusterLabels() {
    Long maxClusterLabel = *std::max_element(gp.begin(),gp.end());
    for(Long i=0; i<gp.size(); ++i) gp[i] = 3*maxClusterLabel - gp[i]+2;
  }

  void changePredPoints(arma::mat newPredPoints) {
    x =  newPredPoints;
    q = x.n_rows;
    pickx = pickx%q;
  }

  Rcpp::List output() {
    return Rcpp::List::create(Rcpp::Named("seed") = seed, Rcpp::Named("q") = q, Rcpp::Named("d") = d,
                              Rcpp::Named("n") = n, Rcpp::Named("N") = N, Rcpp::Named("ordinaryKriging") = ordinaryKriging,
                              Rcpp::Named("covtype") = covtype, Rcpp::Named("sd2") = sd2, Rcpp::Named("x") = x,
                              Rcpp::Named("X") = X, Rcpp::Named("param") = param, Rcpp::Named("gp") = gp,
                              Rcpp::Named("gpsize") = gpsize, Rcpp::Named("Y") = Y, Rcpp::Named("pickx") = pickx);
  }
};


//--------------------------------------------------------- Isolated algo Launcher,

Rcpp::List launchOurAlgo(CaseStudy& cas, Long numThreadsZ=1, Long numThreadsG=1) {
  Rcpp::List resu;
  Long verboseDetails=-1;
  Long outputDetailLevel=2;
  resu=nested_kriging(cas.X, cas.Y, cas.gp, cas.x, cas.covtype, cas.param, cas.sd2,
                        cas.ordinaryKriging, "test", numThreadsZ, numThreadsG, verboseDetails, outputDetailLevel);
  return resu;
}

//------------------------------------------------------------------- Given Cases
// extract our a vector of Algo results for different cases and pickx

class GivenCases {

  arma::vec case_range, pickx_range;
  bool forceSimpleKriging;
  std::string covtype;
  Long numThreadsZone, numThreadsGroups;
  double increaseLengthscales;

  bool changePickx, changeGroupsTo1, changeGroupsTon;
  long largerDataFactor;

  void alarm() {
    std::cout << "Probleme indice " << std::endl;
  }

  arma::vec selecx(arma::mat mymat, Long pickx) {
    if (mymat.n_cols<pickx) alarm();
    return mymat.col(pickx);
  }
  arma::vec selecx(Rcpp::List mylist, Long pickx) {
    if (static_cast<Long>(mylist.length())<pickx) alarm();
    return mylist[pickx];
  }
  double selecx(arma::vec myvec, Long pickx) {
    if (myvec.size()<pickx) alarm();
    return myvec(pickx);
  }

  std::vector<double> caseVarianceVector;

  template <class ResultType, class OutputType>
  std::vector<OutputType> ourPredictions(std::string resultName) {
    std::vector<OutputType> ourResults;
    caseVarianceVector.clear();
    for(Long caseNumber : case_range) {
      CaseStudy cas=CaseStudy(caseNumber, covtype, largerDataFactor);
      if (forceSimpleKriging) cas.setSimpleKriging();
      if (changeGroupsTo1) cas.setGroupsN_equals_1();
      if (changeGroupsTon) cas.setGroupsN_equals_n();
      cas.param = cas.param + increaseLengthscales;
      Rcpp::List ourListResult = launchOurAlgo(cas, numThreadsZone, numThreadsGroups);
      ResultType ourVector = ourListResult[resultName];
      if (!changePickx) pickx_range=std::to_string(cas.pickx);
      for(Long pickx : pickx_range) {
        ourResults.push_back(selecx(ourVector, pickx));
        caseVarianceVector.push_back(cas.sd2);
        }
    }
    return ourResults;
  }

public:
  arma::vec caseVariances() { return arma::conv_to<arma::vec>::from(caseVarianceVector); }
  GivenCases(arma::vec case_range, std::string covtype, long largerDataFactor=1) : case_range(case_range), pickx_range(arma::vec()),
  forceSimpleKriging(false), covtype(covtype), numThreadsZone(1), numThreadsGroups(1),
  increaseLengthscales(0.0), changePickx(false), changeGroupsTo1(false), changeGroupsTon(false), largerDataFactor(largerDataFactor) {}

  void whenSimpleKriging() { forceSimpleKriging=true; }
  void whenPickxBrowse(arma::vec range) { pickx_range=range; changePickx=true; };
  void whenThreadsNumberAre(Long threadsZone, Long threadsGroups) { numThreadsZone=threadsZone; numThreadsGroups=threadsGroups; }
  void whenLengthScalesAreIncreasedBy(double value) { increaseLengthscales=value; }
  void whenGroupsN_equals_n() { changeGroupsTo1=false; changeGroupsTon=true;  }
  void whenGroupsN_equals_1() { changeGroupsTo1=true;  changeGroupsTon=false; }

  std::vector<double>    ourMeans()   { return ourPredictions<arma::vec, double>("mean"); }
  std::vector<double>    ourSd2s()    { return ourPredictions<arma::vec, double>("sd2"); }
  std::vector<arma::vec> ourYhats()   { return ourPredictions<Rcpp::List, arma::vec>("Yhat"); }
  std::vector<arma::vec> ourWeights() { return ourPredictions<arma::mat, arma::vec>("weights"); }
  std::vector<arma::vec> ourKMs()     { return ourPredictions<Rcpp::List, arma::vec>("K_M"); }
  std::vector<arma::vec> ourkMs()     { return ourPredictions<Rcpp::List, arma::vec>("k_M"); }
};

//=================================================================================
//                        TESTS
//=================================================================================

//================================================== Part 0, test environment

Test testPlatformIndependentRng() {
  Test test("0_ unchanged random number generator");
  arma::vec alea(1000);
  Rng rng(1234);
  for(long i=0; i<1000; ++i) alea(i)=rng();
  test.assertClose(alea(999), 0.143971163847, "value of rank 999");
  test.assertClose(alea(1), 0.317630568667, "value of rank 1");
  return test;
}

Test testPlatformIndependentCaseStudy() {
Test test("0_ unmodified and platform independent case Study");
  test.createSection("unchanged case study one");
  CaseStudy myCase(1, "gauss");
  test.assertClose(myCase.d, 2, "d");
  test.assertClose(myCase.X(6,1), -1.19954047242, "X(6,1)");
  test.assertClose(myCase.n, 58, "n");
  myCase.increaseLengthScalesBy(-0.5); // Temporary
  test.assertClose(myCase.param(0), 0.194089232429, "param0");
  test.assertClose(myCase.param(1), 1.45772943374, "param1");
  test.assertClose(myCase.Y(34), -6.08396515287, "Y(34)");
  return test;
}

//==================================================== Part I, Unit Tests

//---------------------------------------------------- test ProgressBar
Test testProgressBar() {
  Test test("I_ Progress bar ticks");
  Chrono chrono("test progressBar");
  std::vector<Long> totalSeq {19, 30,  25, 100, 100, 100, 100, 2500};
  std::vector<Long> nbStepsSeq {5, 5, 7, 97, 10, 1, 100, 5};

  bool statusScreen = screen.showMessages;
  screen.showMessages = false;
  bool asTickB=true, asTickC=true, doneOk=true;
  for(Long k=0; k<totalSeq.size(); ++k) {
    Long total=totalSeq[k], nbSteps=nbStepsSeq[k];
    ProgressBar<1> progressBar(chrono, total, nbSteps);
    Long previousTick=progressBar.nextTick;
    for(Long done=1; done<=total; ++done) {
      progressBar.next();
      doneOk = doneOk && (done==progressBar.done);
      //three methods to determine if it is a new tick
      bool isNewTickA = (progressBar.nextTick>previousTick);
      bool isNewTickB = (floor((done*nbSteps)/total) > floor(((done-1)*nbSteps)/total)) ;
      bool isNewTickC = ((done*nbSteps)%total) < nbSteps;
      asTickB = asTickB && (isNewTickA==isNewTickB);
      asTickC = asTickC && (isNewTickA==isNewTickC);
      if (isNewTickA) previousTick = progressBar.nextTick;
    }
  test.assertTrue(doneOk, "doneOK, k=" + std::to_string(k));
  test.assertTrue(asTickB, "ticksA == ticksB, k=" + std::to_string(k));
  test.assertTrue(asTickC, "ticksA == ticksC, k=" + std::to_string(k));
  }
  screen.showMessages = statusScreen;
  return test;
}
//---------------------------------------------------- test Kernel

arma::mat getK(Long numCaseStudy, std::string covtype, double increaseLengthScales=0.0) {
  CaseStudy myCase(numCaseStudy, covtype);
  myCase.covtype=covtype;
  myCase.increaseLengthScalesBy(increaseLengthScales);
  ChosenKernel kernel(myCase.d, myCase.param, myCase.sd2, covtype);
  ScaledData scaledData(myCase.d, myCase.X, myCase.x, myCase.Y, kernel);
  arma::mat K;
  kernel.fillCorrMatrix(K, scaledData.designPoints);
  return K;
}

Test testKernelSym() {
  Test test("I_ Symmetric correlation matrix with diagonal equal one");
  arma::mat K = getK(1, "gauss");
  test.assertCloseValues(K, K.t(), "K=K.t()");
  test.assertCloseValues(K.diag(), arma::ones(K.n_rows), "K.diag()=ones()");
  return test;
}

Test testKernelGaussDimTwo() {
  Test test("I_ kernel Gauss dim 2");
  CaseStudy myCase(1, "gauss");
  ChosenKernel kernel(myCase.d, myCase.param, myCase.sd2, myCase.covtype);
  ScaledData scaledData(myCase.d, myCase.X, myCase.x, myCase.Y, kernel);
  arma::mat K; kernel.fillCorrMatrix(K, scaledData.designPoints);
  test.createSection("test fill Corr Matrix");
  unsigned long i=myCase.n-1;
  arma::rowvec x1 = myCase.X.row(0);
  arma::rowvec x2 = myCase.X.row(i);
  arma::vec theta = myCase.param;
  test.assertClose(myCase.d, 2);
  test.assertClose(K(0,i), exp(-pow(x1(0)-x2(0),2)/(2*pow(theta(0),2))- pow(x1(1)-x2(1),2)/(2*pow(theta(1),2))));
  test.createSection("test fill CrossCorr");
  arma::mat K3; kernel.fillCrossCorrelations(K3, scaledData.designPoints, scaledData.predictionPoints);
  unsigned long j=myCase.q-1;
  arma::rowvec x3 = myCase.x.row(0);
  arma::rowvec x4 = myCase.x.row(j);
  test.assertClose(K3(0,0), exp(-pow(x1(0)-x3(0),2)/(2*pow(theta(0),2))- pow(x1(1)-x3(1),2)/(2*pow(theta(1),2))));
  test.assertClose(K3(0,j), exp(-pow(x1(0)-x4(0),2)/(2*pow(theta(0),2))- pow(x1(1)-x4(1),2)/(2*pow(theta(1),2))));
  test.assertClose(K3(i,j), exp(-pow(x2(0)-x4(0),2)/(2*pow(theta(0),2))- pow(x2(1)-x4(1),2)/(2*pow(theta(1),2))));
  test.assertClose(K3(i,0), exp(-pow(x2(0)-x3(0),2)/(2*pow(theta(0),2))- pow(x2(1)-x3(1),2)/(2*pow(theta(1),2))));
  return test;
}

Test testRetrieveCorrFromCrossCorr() {
  Test test("I_ CrossCorr Matrix(X,X) = Corr");
  CaseStudy myCase(1, "gauss");
  ChosenKernel kernel(myCase.d, myCase.param, myCase.sd2, myCase.covtype);
  ScaledData scaledData(myCase.d, myCase.X, myCase.x, myCase.Y, kernel);
  arma::mat K1; kernel.fillCorrMatrix(K1, scaledData.designPoints);
  arma::mat K2; kernel.fillCrossCorrelations(K2, scaledData.designPoints, scaledData.designPoints);
  test.assertCloseValues(K1,K2);
  return test;
}

Test testKernelIdenticalNicolas() {
    Test test("I_ Kernel, corr as Nicolas Python code");
    test.createSection("gauss");
    arma::mat Kaa=getK(1, "gauss", -0.5);
    test.assertClose(Kaa(2-1,3-1), 0.35032997004240202, "K(2,3)");
    test.assertClose(Kaa(56-1,57-1), 0.83852598862397587, "K(5,6)");
    arma::mat Ka=getK(1, "gauss", 0.0);
    test.assertClose(Ka(2-1,3-1), 0.55908071, "K(2,3)");
    test.assertClose(Ka(56-1,57-1), 0.96949139, "K(5,6)");
    test.createSection("matern3_2");
    arma::mat Kb=getK(1, "matern3_2", 0.0);
    test.assertClose(Kb(2-1,3-1), 0.44295216, "K(2,3)");
    test.assertClose(Kb(56-1,57-1), 0.92572726, "K(5,6)");
    test.createSection("matern5_2");
    arma::mat Kc=getK(1, "matern5_2", 0.0);
    test.assertClose(Kc(2-1,3-1), 0.4798198, "K(2,3)");
    test.assertClose(Kc(56-1,57-1), 0.95067595, "K(5,6)");
    test.createSection("exp");
    arma::mat Kd=getK(1, "exp", 0.0);
    test.assertClose(Kd(2-1,3-1), 0.33850451, "K(2,3)");
    test.assertClose(Kd(56-1,57-1), 0.70599644, "K(5,6)");
  return test;
  }

//---------------------------------------------------- test Ranks
Test testRanks() {
  Test test("I_ Ranks");
  arma::vec myvec("3 5 5 3 6 2 5 5 3 3 3 5 2");
  arma::vec expectedRanks("1 2 2 1 3 0 2 2 1 1 1 2 0");
  Ranks<arma::vec> ranks(myvec);
  test.createSection("distinct values");
  test.assertClose(ranks.countDistinctValues(), 4, "ranks, distinct values");
  test.createSection("values by rank");
  test.assertClose(ranks.countByRank(0), 2, "ranks, countByRank(0)");
  test.assertClose(ranks.countByRank(1), 5, "ranks, countByRank(1)");
  test.assertClose(ranks.countByRank(2), 5, "ranks, countByRank(2)");
  test.assertClose(ranks.countByRank(3), 1, "ranks, countByRank(3)");
  Long totalCount = 0;
  for(Long i=0; i<ranks.countDistinctValues(); ++i) totalCount += ranks.countByRank(i);
  test.assertClose(totalCount, myvec.size(), "ranks, total count");
  test.createSection("values by rank");
  arma::vec calculatedRanks(myvec.size());
  test.assertClose(ranks.rankOf(2), 0, "rankOf(3)");
  test.assertClose(ranks.rankOf(3), 1, "rankOf(3)");
  test.assertClose(ranks.rankOf(5), 2, "rankOf(3)");
  test.assertClose(ranks.rankOf(6), 3, "rankOf(3)");
  for(Long i=0; i<myvec.size(); ++i) calculatedRanks[i] = ranks.rankOf(myvec[i]);
  test.assertCloseValues(calculatedRanks, expectedRanks, "expected rank vector");
  return test;
}

//---------------------------------------------------- test Splitter

struct SplitterInspected : public Splitter {
  SplitterInspected() : Splitter() {}
  explicit SplitterInspected(const std::vector<Long>& splitScheme) : Splitter(splitScheme) { }
  explicit SplitterInspected(const arma::vec& splitScheme)  : Splitter(splitScheme) { }

  bool isAllocationTight() {
    bool tight=true;
    for(Long i=0; i<get_N(); ++i) tight = tight && (obsByGroup[i].capacity()==obsByGroup[i].size());
    return tight;
  }
};

Test testSplitterA() {
   Test test("I_ Splitter A - split vectors");
     arma::vec myvec("1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8 9.9");
   test.createSection("correct splitted vectors user groups");
     Splitter splitter(arma::vec("1 1 1 2 2 2 3 3 3"));
     std::vector<arma::vec> myOutput;
     splitter.split<arma::vec>(myvec, myOutput);
     test.assertCloseValues(myOutput[0], arma::vec("1.1 2.2 3.3"), "group 0");
     test.assertCloseValues(myOutput[1], arma::vec("4.4 5.5 6.6"), "group 1");
     test.assertCloseValues(myOutput[2], arma::vec("7.7 8.8 9.9"), "group 2");
   test.createSection("correct splitted vectors modulo scheme");
     Splitter splitter2;
     splitter2.setModuloSplitScheme(myvec.n_elem, 4);
     splitter2.split<arma::vec>(myvec, myOutput);
     test.assertCloseValues(myOutput[0], arma::vec("1.1 5.5 9.9"), "group 0");
     test.assertCloseValues(myOutput[1], arma::vec("2.2 6.6"), "group 1");
     test.assertCloseValues(myOutput[2], arma::vec("3.3 7.7"), "group 2");
     test.assertCloseValues(myOutput[3], arma::vec("4.4 8.8"), "group 3");
   return test;
}

Test testSplitterB() {
  Test test("I_ Splitter B - rowvec, split and merge");
   test.createSection("correct splitted vectors arma::rowvec");
     Splitter splitter3;
     arma::vec myvec("1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8 9.9");
     splitter3.setModuloSplitScheme(myvec.n_elem, 3);
     std::vector<arma::rowvec> splittedRowvec;
     splitter3.split<arma::rowvec>(myvec.t(), splittedRowvec);
     test.assertCloseValues(splittedRowvec[0], arma::rowvec("1.1 4.4 7.7"), "group 0");
     test.assertCloseValues(splittedRowvec[1], arma::rowvec("2.2 5.5 8.8"), "group 1");
     test.assertCloseValues(splittedRowvec[2], arma::rowvec("3.3 6.6 9.9"), "group 2");
   test.createSection("split and merge");
     arma::rowvec mergedRowVec;
     splitter3.merge<arma::rowvec>(splittedRowvec, mergedRowVec);
     test.assertCloseValues<arma::rowvec>(mergedRowVec, myvec.t(), "merge rowvec");
     arma::vec mergedVec; std::vector<arma::vec> splittedVec;
     Splitter splitter5(arma::vec("1 2 3 3 4 2 1 2 2"));
     splitter5.split(myvec, splittedVec);
     splitter5.merge(splittedVec, mergedVec);
     test.assertCloseValues(mergedVec, myvec, "merge vec");
 return test;
}

Test testSplitterC() {
   Test test("I_ Splitter C - matrices");
   test.createSection("correct splitted and remerged matrices");
     arma::mat myMat("1.1 1.2 1.3; 2.1 2.2 2.3; 3.1 3.2 3.3; 4.1 4.2 4.3; 5.1 5.2 5.3");
     Splitter splitter4(arma::vec("1 2 1 1 2"));
     std::vector<arma::mat> splittedMat;
     splitter4.splitMat(myMat, splittedMat);
     test.assertCloseValues(splittedMat[0], arma::mat("1.1 1.2 1.3; 3.1 3.2 3.3; 4.1 4.2 4.3"), "group 0");
     test.assertCloseValues(splittedMat[1], arma::mat("2.1 2.2 2.3; 5.1 5.2 5.3"), "group 1");
     arma::mat myMergedMat;
     splitter4.mergeMat(splittedMat, myMergedMat);
     test.assertCloseValues(myMergedMat, myMat, "remerged matrix");
  return test;
}

Test testSplitterD() {
   Test test("I_ Splitter D - with empty groups, allocation");
   test.createSection("tight allocation");
     SplitterInspected splitterD(arma::vec("1 1 1 2 2 2 3 3 3"));
     test.assertTrue(splitterD.isAllocationTight(), "a");
     SplitterInspected splitterD2(arma::vec("1 5 1 2 8 8 3 3 3"));
     test.assertTrue(splitterD2.isAllocationTight(), "b");
     arma::vec largeVec(1000); largeVec.fill(0);
     SplitterInspected splitterD3=SplitterInspected();
     splitterD3.setModuloSplitScheme(1000,123);
     test.assertTrue(splitterD3.isAllocationTight(), "c");
   test.createSection("test with empty groups");
     arma::vec myvec("1.1 2.2 3.3 4.4 5.5 6.6 7.7 8.8 9.9");
     std::vector<arma::vec> splittedVec;
     Splitter splitter6(arma::vec("1 6 4 6 6 6 6 4 4"));
     test.assertClose(splitter6.get_N(),3, "get_N");
     splitter6.split(myvec,splittedVec);
     test.assertCloseValues(splittedVec[0], arma::vec("1.1"), "group 0");
     test.assertCloseValues(splittedVec[1], arma::vec("3.3 8.8 9.9"), "group 1");
     test.assertCloseValues(splittedVec[2], arma::vec("2.2 4.4 5.5 6.6 7.7"), "group 2");
   return test;
  }

//==================================================== Part II Check Intermediate Results with Other Implementations

//---------------------------------------------------- Yhat

Test testIdenticalYhatNicolasCase1() {
  Test test("II_ Yhat as Nicolas Python code. caseStudy 1, SimpleK");
  arma::vec NicoYhat_pick0("1.82785080e-02 1.57634801e+02 -1.71017950e+00 5.15097551e-01 1.26098334e-03");
  arma::vec NicoYhat_pick1("3.40773320e-08 4.15406351e+00 4.32264312e+00 -2.73526153e+00 2.91756920e+00");
  GivenCases cases("1", "gauss");
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1");
  test.assertCloseValues(cases.ourYhats()[0], NicoYhat_pick0, "pick0");
  test.assertCloseValues(cases.ourYhats()[1], NicoYhat_pick1, "pick1");
  return test;
}

Test testIdenticalYhatNicolasCase2() {
  Test test("II_ Yhat as Nicolas Python code. caseStudy 2, SimpleK");
  arma::vec NicoYhat_pick0("-1.72125267e-02 -2.44016326e-01 -2.16280661e+00 -6.36993226e-01 -2.05265060e-03 -3.44870638e-06");
  arma::vec NicoYhat_pick1("-2.81485949e-05 -6.62849679e-02 2.74925606e-01 9.38217536e-02 -1.21302961e-01 -7.29976073e-05");
  GivenCases cases("2", "gauss");
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1");
  test.assertCloseValues(cases.ourYhats()[0], NicoYhat_pick0, "pick0");
  test.assertCloseValues(cases.ourYhats()[1], NicoYhat_pick1, "pick1");
  return test;
}

Test testIdenticalYhatClement() {
  Test test("II_ Yhat as Clement code, case 2");
  arma::vec ClemYhat_pick0("-1.721253e-02 -2.440163e-01 -2.162807e+00 -6.369932e-01 -2.052651e-03 -3.448706e-06");
  arma::vec ClemYhat_pick1("-2.814859e-05 -6.628497e-02  2.749256e-01  9.382175e-02 -1.213030e-01 -7.299761e-05");
  GivenCases cases("2", "gauss");
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1");
  test.assertCloseValues(cases.ourYhats()[0], ClemYhat_pick0, "pick0");
  test.assertCloseValues(cases.ourYhats()[1], ClemYhat_pick1, "pick1");
  return test;
}

Test testIdenticalYhatClementSmallLengthScales() {
  Test test("II_ Yhat as Clement code, case 2, small LengthScales");
  arma::vec ClemYhat_pick0("-5.059847e-21 -7.509132e-07 -2.316487e-01 -6.701788e-02 -1.348031e-17  6.750445e-37");
  arma::vec ClemYhat_pick1("-6.821659e-37 -8.924331e-13  4.300477e-03 -7.049074e-02  1.709589e-09  6.913394e-22");
  GivenCases cases("2", "gauss");
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1");
  cases.whenLengthScalesAreIncreasedBy(-0.5);
  test.assertCloseValues(cases.ourYhats()[0], ClemYhat_pick0, "pick0");
  test.assertCloseValues(cases.ourYhats()[1], ClemYhat_pick1, "pick1");
  return test;
}

Test testIdenticalYhatNicolasSmallLengthScales() {
  Test test("II_ Yhat as Nicolas Python code. caseStudy 1, SimpleK, small lengthscales");
  arma::vec NicoYhat_pick0("1.35181103e-36   1.20985236e+01   9.41030180e-01 -5.95208551e-18  5.63688606e-61");
  arma::vec NicoYhat_pick1("2.27785166e-111  -2.72258794e-029 1.07484386e-001   1.18858049e+000  4.90976232e-011");
  GivenCases cases("1", "gauss");
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1");
  cases.whenLengthScalesAreIncreasedBy(-0.5);
  test.setPrecision(5e-5);
  test.assertCloseValues(cases.ourYhats()[0], NicoYhat_pick0, "pick 0");
  test.assertCloseValues(cases.ourYhats()[1], NicoYhat_pick1, "pick 1");
  return test;
}

//-------------------------------------------------------- Submodels Correlation Matrices

Test testIdenticalCorrMatrixK() {
  Test test("II_ Correlation matrices K as Clement C++ code, pickx=0");
  CaseStudy caseTwo=CaseStudy(2, "gauss");
  caseTwo.pickx=0;
  arma::vec KClemFragmentA("4.048285e-06 2.141938e-06 4.745261e-05 7.625594e-08 1.920825e-16 6.815868e-26 2.141938e-06 1.426723e-03 2.057611e-03 5.444947e-04 1.836574e-11");
  arma::vec KClemFragmentB("1.836574e-11 4.289529e-07 8.625786e-06 2.761102e-06 8.274330e-12 6.815868e-26 9.396721e-18 8.749128e-15 2.079975e-11 8.274330e-12 4.659941e-13");
  KClemFragmentA = KClemFragmentA/caseTwo.sd2;
  KClemFragmentB = KClemFragmentB/caseTwo.sd2;
  Rcpp::List ourResult=launchOurAlgo(caseTwo);
  Rcpp::List allK_M= ourResult["K_M"];
  arma::vec ourK_M =  allK_M[caseTwo.pickx];
  arma::vec ourK_MA = ourK_M.head(KClemFragmentA.size());
  arma::vec ourK_MB = ourK_M.tail(KClemFragmentB.size());
  test.assertCloseValues(ourK_MA, KClemFragmentA, "fragment A");
  test.assertCloseValues(ourK_MB, KClemFragmentB, "fragment B");
  return test;
}

Test testIdenticalCrossCorrMatrixk() {
  Test test("II_ Cross correlation matrices k as Clement C++ code");
  arma::vec kClem0("4.048285e-06 1.426723e-03 7.063288e-01 4.820011e-01 2.761102e-06 4.659941e-13");
  arma::vec kClem1("1.304796e-11 1.202706e-04 5.600021e-01 2.833904e-01 3.982282e-03 4.612748e-08");
  kClem0 = kClem0/CaseStudy(2, "gauss").sd2;
  kClem1 = kClem1/CaseStudy(2, "gauss").sd2;
  GivenCases mycases("2", "gauss");
  mycases.whenPickxBrowse("0 1");
  test.assertCloseValues(mycases.ourkMs()[0], kClem0, "pickx=0");
  test.assertCloseValues(mycases.ourkMs()[1], kClem1, "pickx=1");
  return test;
}

Test testIdenticalCorrMatrixKSmallLengthScales() {
  Test test("II_ Correlation matrices K as Clement C++ code, pickx=0, small lengthscales");
  CaseStudy caseTwo=CaseStudy(2, "gauss");
  caseTwo.increaseLengthScalesBy(-0.5);
  caseTwo.pickx=0;
  arma::vec KClemFragmentA("6.712984e-43 1.045742e-36 1.242392e-34 1.010777e-54 2.004957e-112 3.101577e-159 1.045742e-36 1.963845e-14");
  arma::vec KClemFragmentB("3.101577e-159 9.936463e-98 1.855292e-74 -2.622529e-51 1.443322e-63 1.921502e-73");
  KClemFragmentA = KClemFragmentA/caseTwo.sd2;
  KClemFragmentB = KClemFragmentB/caseTwo.sd2;
  Rcpp::List ourResult=launchOurAlgo(caseTwo);
  Rcpp::List allK_M= ourResult["K_M"];
  arma::vec ourK_M =  allK_M[caseTwo.pickx];
  arma::vec ourK_MA = ourK_M.head(KClemFragmentA.size());
  arma::vec ourK_MB = ourK_M.tail(KClemFragmentB.size());
  test.assertCloseValues(ourK_MA, KClemFragmentA, "fragment A");
  test.assertCloseValues(ourK_MB, KClemFragmentB, "fragment B");
  return test;
}

Test testIdenticalCrossCorrMatrixkSmallLengthScales() {
  Test test("II_ Cross correlation matrices k as Clement code, small lengthscales");
  arma::vec kClem0("6.712984e-43 1.963845e-14 3.282007e-03 2.774995e-03 1.568177e-35 1.921502e-73");
  arma::vec kClem1("1.220171e-74 2.767811e-26 9.845388e-03 8.541866e-03 1.332917e-18 1.154473e-42");
  kClem0 = kClem0/CaseStudy(2, "gauss").sd2;
  kClem1 = kClem1/CaseStudy(2, "gauss").sd2;
  GivenCases mycases("2", "gauss");
  mycases.whenLengthScalesAreIncreasedBy(-0.5);
  mycases.whenPickxBrowse("0 1");
  test.assertCloseValues(mycases.ourkMs()[0], kClem0, "pickx=0");
  test.assertCloseValues(mycases.ourkMs()[1], kClem1, "pickx=1");
  return test;
}

//--------------------------------------------------------------- Weights

Test testIdenticalWeightClement() {
  Test test("II_ Weights as Clement C++ code, case 2");
  arma::vec ClemWeight0("-9.2072255 -0.5971953  0.8964170  0.8337995 -1.7440646 -5.2655129");
  arma::vec ClemWeight1("16.48590651 -0.04870886 0.90603491 0.78658069 0.87051025 -22.24305121");
  GivenCases cases("2", "gauss");
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1");
  test.setPrecision(1e-4);
  test.assertCloseValues(cases.ourWeights()[0], ClemWeight0, "pickx=0");
  test.assertCloseValues(cases.ourWeights()[1], ClemWeight1, "pickx=1");
  return test;
}


Test testWeightsSolveSystem() {
  Test test("II_ Weights solve matrix equation: K_M weights= k_M");
  test.setPrecision(1e-6, 1e-15);
  GivenCases mycases("2", "gauss");
  mycases.whenSimpleKriging();
  mycases.whenPickxBrowse("0 1");
  for(unsigned long pickx=0; pickx<2; ++pickx) {
    arma::vec k_M = mycases.ourkMs()[pickx];
    arma::vec alpha = mycases.ourWeights()[pickx];
    arma::vec flatKM = mycases.ourKMs()[pickx];
    arma::mat K_M = arma::reshape(flatKM, k_M.n_rows, k_M.n_rows);
    arma::vec shouldBeCloseToZero=K_M*alpha-k_M;
    test.assertCloseValues(shouldBeCloseToZero, arma::zeros(k_M.n_rows), "pickx=" + std::to_string(pickx));
  }
  return test;
}

//==================================================== Part III Check Final Results - alone
// whole system test, without external references. final results
Test testOneDesignPointOnly() {
    Test test("III_ Test with only one design point");
  for(Long caseIndex=1; caseIndex< 5; ++caseIndex) {
    test.createSection("case "+std::to_string(caseIndex));
    CaseStudy myCase(caseIndex, "gauss");
    myCase.keepOnlyOneObservation(0);
    myCase.setSimpleKriging();
    myCase.increaseLengthScalesBy(2.3); // to ensure larger variance variations
    // algo results
    Rcpp::List resu = launchOurAlgo(myCase);
    arma::vec calculatedMean= resu["mean"];
    arma::vec calculatedSd2= resu["sd2"];
    // expected results
    ChosenKernel kernel(myCase.d, myCase.param, myCase.sd2, myCase.covtype);
    ScaledData scaledData(myCase.d, myCase.X, myCase.x, myCase.Y, kernel);
    arma::mat k;
    kernel.fillCrossCorrelations(k, scaledData.designPoints, scaledData.predictionPoints);
    for(Long i=0; i<myCase.x.n_rows; ++i) {
      double expectedMean = k[i]*scaledData.Y[0];
      test.assertClose(expectedMean, calculatedMean[i], "mean_" + std::to_string(i));
      double expectedSd2 = myCase.sd2*(1-k[i]*k[i]);
      test.assertClose(expectedSd2, calculatedSd2[i], "sd2_" + std::to_string(i));
    }
  }
  return test;
}

Test testPermutationHasNoImpact() {
  Test test("III_ test permutation and cluster labels has no impact");
  for(Long caseIndex=1; caseIndex< 5; ++caseIndex) {
    test.createSection("case "+std::to_string(caseIndex));
    CaseStudy myCase(caseIndex, "gauss");
    myCase.increaseLengthScalesBy(2.3); // to ensure larger variance variations
    Rcpp::List resu = launchOurAlgo(myCase);
    arma::vec initialMean= resu["mean"];
    arma::vec initialSd2= resu["sd2"];
    double initialY0 = myCase.Y(0);
    myCase.rotateObservations(1);
    myCase.changeClusterLabels();
    Rcpp::List resuPermutation = launchOurAlgo(myCase);
    arma::vec afterPermutationMean= resuPermutation["mean"];
    arma::vec afterPermutationSd2= resuPermutation["sd2"];
    test.assertTrue(fabs(initialY0-myCase.Y(0))>1e-5, "Y has been changed, as expected");
    test.assertClose(initialY0, myCase.Y(1), "Y rotated by one step");
    test.assertCloseValues(initialMean, afterPermutationMean, "mean are unchanged");
    test.assertCloseValues(initialSd2, afterPermutationSd2, "sd2 are unchanged");
    }
  return test;
}

Test testWithRotatedPredPoints() {
  Test test("III_ testWithRotatedPredPoints");
  for(Long caseIndex=1; caseIndex< 8; ++caseIndex) {
    test.createSection("case "+std::to_string(caseIndex));
    CaseStudy myCase(caseIndex, "matern5_2");
    myCase.increaseLengthScalesBy(2.3);
    Rcpp::List resu = launchOurAlgo(myCase);
    arma::vec initialMean= resu["mean"];
    arma::vec initialSd2= resu["sd2"];
    myCase.rotatePredPoints(1);
    Rcpp::List resuPermutation = launchOurAlgo(myCase);
    arma::vec afterPermutationMean= resuPermutation["mean"];
    arma::vec afterPermutationSd2= resuPermutation["sd2"];
    test.assertCloseValues(initialMean, arma::shift(afterPermutationMean, -1), "means are rotated");
    test.assertCloseValues(initialSd2, arma::shift(afterPermutationSd2, -1), "sd2 are rotated");
  }
  return test;
}

Test testInterpolating() {
  Test test("III_ testInterpolating");
  test.setPrecision(1e-8, 1e-13);
  for(Long caseIndex=1; caseIndex< 8; ++caseIndex) {
    test.createSection("case "+std::to_string(caseIndex));
    CaseStudy myCase(caseIndex, "matern5_2");
    myCase.changePredPoints(myCase.X); // predict at interpolation points
    Rcpp::List resu = launchOurAlgo(myCase);
    arma::vec predMean= resu["mean"];
    arma::vec predSd2= resu["sd2"];
    test.assertCloseValues(predMean, myCase.Y, "pred mean are interpolating when x=X");
    test.assertCloseValues(predSd2, arma::zeros(myCase.x.n_rows), "sd2 are zeros when x=X");
  }
  return test;
}




Test testMultithreadCompilation() {
  Test test("III_ Compiled with multithread, with activated parallelism");
  bool compiledWithMultithread = false;
  #if defined(_OPENMP)
    compiledWithMultithread = true;
  #endif
  test.assertTrue(compiledWithMultithread);
  return test;
}


Test testMergeOutputInAlgoZone() {
  Test test("III_ MergeOutputInAlgoZone");
  GivenCases cases("4", "gauss"); //in case study 4, q=9
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1 2 3 4 5 6 7 8");
  cases.whenThreadsNumberAre(1,1);
  std::vector<arma::vec> Yhat_ref = cases.ourYhats();
  std::vector<arma::vec> knu_ref = cases.ourkMs();
  std::vector<arma::vec> Knu_ref = cases.ourKMs();
  GivenCases casesBis("4", "gauss");
  casesBis.whenSimpleKriging();
  casesBis.whenPickxBrowse("0 1 2 3 4 5 6 7 8");

  casesBis.whenThreadsNumberAre(2,4);
  std::vector<arma::vec> Yhat_AlgoZone = casesBis.ourYhats();
  std::vector<arma::vec> knu_AlgoZone = casesBis.ourkMs();
  std::vector<arma::vec> Knu_AlgoZone = cases.ourKMs();
  for(unsigned long pickx=0; pickx<9; ++pickx) {
      test.assertCloseValues(Yhat_ref[pickx], Yhat_AlgoZone[pickx], "Yhat, pickx=" + std::to_string(pickx));
      test.assertCloseValues(knu_ref[pickx], knu_AlgoZone[pickx], "knu, pickx=" + std::to_string(pickx));
      test.assertCloseValues(Knu_ref[pickx], Knu_AlgoZone[pickx], "Knu, pickx=" + std::to_string(pickx));
    }
  return test;
}

Test testNoThreadImpact() {
  std::vector<std::string> covFamily{"gauss", "matern5_2", "matern3_2", "exp"};
  Test test("III_ test no thread Impact ");
  test.setPrecision(1e-10);
  for(auto covtype : covFamily) {
    test.createSection(covtype);
    GivenCases casA("1 2 3 4 5 6 7 8 9", covtype);
    for(long threadsZ=1; threadsZ<2; ++threadsZ)
      for(long threadsG=1; threadsG<4; ++threadsG) {
        GivenCases casB("1 2 3 4 5 6 7 8 9", covtype);
        casB.whenThreadsNumberAre(threadsZ,threadsG);
        test.assertCloseValues(casB.ourMeans(), casA.ourMeans(), "mean");
        test.assertCloseValues(casB.ourSd2s(), casA.ourSd2s(), "sd2");
      }
  }
  return test;
}

Test testTooManyThreads() {
  Test test("III_ testTooManyThreads");
  GivenCases cases("4", "gauss"); //in case study 4, q=9
  cases.whenSimpleKriging();
  cases.whenPickxBrowse("0 1 2 3 4 5 6 7 8");
  cases.whenThreadsNumberAre(1,1);
  std::vector<arma::vec> Yhat_ref = cases.ourYhats();
  cases.whenThreadsNumberAre(100,1);
  std::vector<arma::vec> Yhat_AlgoZone1 = cases.ourYhats();
  cases.whenThreadsNumberAre(1,100);
  std::vector<arma::vec> Yhat_AlgoZone2 = cases.ourYhats();
  cases.whenThreadsNumberAre(100,100);
  std::vector<arma::vec> Yhat_AlgoZone3 = cases.ourYhats();
  for(unsigned long pickx=0; pickx<9; ++pickx) {
    test.assertCloseValues(Yhat_ref[pickx], Yhat_AlgoZone1[pickx], "Yhat1, pickx=" + std::to_string(pickx));
    test.assertCloseValues(Yhat_ref[pickx], Yhat_AlgoZone2[pickx], "Yhat2, pickx=" + std::to_string(pickx));
    test.assertCloseValues(Yhat_ref[pickx], Yhat_AlgoZone3[pickx], "Yhat3, pickx=" + std::to_string(pickx));
  }
  return test;
}

Test testIdenticalExtremeGroups() {
  Test test("III_ (result with N=1) is equal to (result with N=n)");
  test.setPrecision(2e-6);
  std::vector<std::string> covFamily{"gauss", "matern5_2", "matern3_2", "exp"};
  for(auto cov : covFamily) {
    test.createSection(cov);
    GivenCases config1("1 2 3 5 6 7 8 9", cov);
    config1.whenSimpleKriging();
    config1.whenGroupsN_equals_1();
    GivenCases config2("1 2 3 5 6 7 8 9", cov);
    config2.whenSimpleKriging();
    config2.whenGroupsN_equals_n();
    test.assertCloseValues(config1.ourMeans(), config2.ourMeans(), "means");
    test.assertCloseValues(config1.ourSd2s(), config2.ourSd2s(), "sd2");
  }
  return test;
}

//==================================================== Part IV Check Final Results - as other codes
// whole system test, final results Nested Kriging mean and variance

Test testIdenticalMeanSd2WithClement() {
  Test test("IV_ mean and sd2 as Clement C++ code.");

  std::vector<std::string> covFamily{"gauss", "matern5_2", "matern3_2", "exp"};
  std::map<std::string,arma::vec> means, sd2;

  means["gauss"]=arma::vec("7.78702081646 -2.16209819079 0.040518685552 0.682200808437 -0.22666297305 -0.358825347683 -0.973703477664 0.251432662089 -0.472100563115");
  sd2["gauss"]=arma::vec("0.0080279025041 0.717510127216 2.62654416333 1.28776484283 0.317415361568 1.2546970103 2.07595623566 2.58957113494 0.0375837239292");
  means["matern5_2"] = arma::vec("-0.449699784018 -1.53233278855 0.051274907898 0.486252668642 -0.844064677964 -0.381072951942 -0.656189148547 0.375893134363 0.679487203904");
  sd2["matern5_2"] = arma::vec("0.0520821386274 1.01653533398 2.62602937915 1.29157132434 0.350671237279 1.25462136488 2.11548753978 2.58948093182 0.0822965597606");
  means["matern3_2"]=arma::vec("0.84288792223 -1.35874420328 0.0524823069943 0.394310087603 -1.02323712669 -0.360115426449 -0.498835899598 0.398927561972 0.75745302593");
  sd2["matern3_2"]=arma::vec("0.12585018748 1.15440507595 2.62601468935 1.29281697373 0.362013490918 1.25466127551 2.12362046196 2.58955440089 0.201063110466");
  means["exp"]=arma::vec("1.83305500098 -0.97895481936 0.0450769854035 0.161650114341 -0.737559871047 -0.21338322446 -0.151207565621 0.333511621427 0.378646250446");
  sd2["exp"]=arma::vec("0.476826519582 1.49362135478 2.62662741074 1.29498229157 0.377366581966 1.25489749607 2.13043629045 2.59022571774 1.32491700812");

  test.setPrecision(1e-9);
  for(auto family : covFamily) {
    GivenCases cases("1 2 3 4 5 6 7 8 9", family);
    test.assertCloseValues(cases.ourMeans(), means[family], "mean " + family);
    test.assertCloseValues(cases.ourSd2s(), sd2[family], "sd2 " + family);
  }
  return test;
}


Test testIdenticalMeanSd2WithClementSK() {
  Test test("IV_ mean and sd2 as Clement C++ code, Simple Kriging");
  std::vector<std::string> covFamily{"gauss"};
  std::map<std::string,arma::vec> meansSK, sd2SK;
  meansSK["gauss"] = arma::vec("9.09250068606 -2.16209819079 0.0341859074311 0.682200808437 0.425208951451 -0.358825347683 0.0838039861629 0.251432662089 -0.462140082667");
  sd2SK["gauss"] = arma::vec("0.00800828323515 0.717510127216 2.62384489095 1.28776484283 0.310303532083 1.2546970103 2.05053679682 2.58957113494 0.0326674713491");

  test.setPrecision(2e-10);
  for(auto family : covFamily) {
    GivenCases cases("1 2 3 4 5 6 7 8 9", family);
    cases.whenSimpleKriging();
    test.assertCloseValues(cases.ourMeans(), meansSK[family], "mean_SK " + family);
    test.assertCloseValues(cases.ourSd2s(), sd2SK[family], "sd2_SK " + family);
  }
  return test;
}

Test testIdenticalMeanSd2WithNicolasSKfocus1() {
  Test test("IV_ mean and sd2 as Nicolas Python code, case 1, SimpleK");
  std::vector<std::string> covFamily{"gauss"};
  std::map<std::string,arma::vec> meansSK, sd2SK;
  meansSK["gauss"] = arma::vec("9.09250069 -1.34216916");
  sd2SK["gauss"] = arma::vec("0.86782846 0.87305419");
  std::string tag = "Simple Kriging, pickx=0..1";
  for(auto family : covFamily) {
    GivenCases cases("1", family);
    cases.whenSimpleKriging();
    cases.whenPickxBrowse("0 1");
    cases.whenLengthScalesAreIncreasedBy(0.0);
    test.setPrecision(0.002); //WARNING LOW PRECISION for mean of pick1
    test.assertCloseValues(cases.ourMeans(), meansSK[family], tag + ", mean_SK " + family);
    test.assertCloseValues(cases.ourSd2s(), cases.caseVariances()-sd2SK[family], tag + ", sd2_SK " + family);//OK
  }
  return test;
}

Test testIdenticalMeanSd2WithNicolasSKfocus2() {
  Test test("IV_ mean and sd2 as Nicolas Python code, case 2, SimpleK");
  std::vector<std::string> covFamily{"gauss"};
  std::map<std::string,arma::vec> meansSK, sd2SK;
  meansSK["gauss"] = arma::vec("-2.16209819 0.2216834");
  sd2SK["gauss"] = arma::vec("1.03416336 0.73375059");
  std::string tag = "Simple Kriging, pickx=0..1";
  for(auto family : covFamily) {
    GivenCases cases("2", family);
    cases.whenThreadsNumberAre(2,4);
    cases.whenSimpleKriging();
    cases.whenPickxBrowse("0 1");
    cases.whenLengthScalesAreIncreasedBy(0.0);
    test.setPrecision(2e-8);
    test.assertCloseValues(cases.ourMeans(), meansSK[family], tag + ", mean_SK " + family);
    test.assertCloseValues(cases.ourSd2s(), cases.caseVariances()-sd2SK[family], tag + ", sd2_SK " + family);//OK
  }
  return test;
}

Test testIdenticalDiceKriging() {
  Test test("IV_ mean and sd2 as DiceKriging Case 1, Simple Kriging");
  arma::vec meanGaussDiceCas1("3.010741 -1.084594");
  arma::vec sd2GaussDiceCas1("0.0026667431 0.0004412312");
  CaseStudy mycase(1, "gauss");
  mycase.ordinaryKriging=false;

  test.createSection("case N=1, gauss");
  mycase.setGroupsN_equals_1();
  Rcpp::List resuA = launchOurAlgo(mycase, 1, 1);
  arma::vec ourMeanA = resuA["mean"], oursd2A=resuA["sd2"];
  test.setPrecision(5e-8);
  test.assertCloseValues(ourMeanA, meanGaussDiceCas1, "mean");
  test.assertCloseValues(oursd2A, sd2GaussDiceCas1, "variance");

  test.createSection("case N=n, gauss");
  mycase.setGroupsN_equals_n();
  Rcpp::List resuB = launchOurAlgo(mycase, 1, 1);
  arma::vec ourMeanB = resuB["mean"], oursd2B=resuB["sd2"];
  test.setPrecision(2e-5);
  test.assertCloseValues(ourMeanB, meanGaussDiceCas1, "mean");
  test.assertCloseValues(oursd2B, sd2GaussDiceCas1, "variance");

  return(test);
}

Test testNoCriticalStopWithLargerData() {
  //a critical bug with AlgoZone was undetected before this test: to be kept
  Test test("IV_ no critical Stop with larger Data");
  std::vector<std::string> covFamily{"gauss"};
  std::map<std::string,arma::vec> meansSK, sd2SK;
  std::string tag = "Simple Kriging, pickx=0..1";
  for(auto family : covFamily) {
    bool largerDataFactor=10;
    GivenCases cases("2", family, largerDataFactor);
    cases.whenSimpleKriging();
    cases.whenPickxBrowse("0 1");
    cases.whenLengthScalesAreIncreasedBy(0.0);
    test.setPrecision(2e-8);
    test.assertClose(cases.ourMeans()[0]*0.0, 0.0, tag + ", mean_SK " + family);
    test.assertClose(cases.ourSd2s()[1]*0.0, 0.0, tag + ", sd2_SK " + family);
  }
  return test;
}

//========================================================== Part V Interface with R

} // end namespace

#endif
