rm(list=ls(all=TRUE))

#############################################
#                                           #
#  demoE.R : tests and version information  #
#                                           #
#############################################

#########################################
#### library installation (you might need to install Rtools before)
#### in RStudio:
#### go to menu Tools, Install Package...,
#### select Install from Package Archive File,
#### select nestedKriging_xxx.tar.gz

#########################################

library(nestedKriging)

#########################################
#### manual tests

caseStudyOne <- tests_getCaseStudy(1, "gauss")

myResults <- tests_getCodeValues(1, "gauss", forceSimpleKriging = TRUE)

#### to be compared with other implementations

#########################################
#### launch tests with details on failures only


#### eventual debugging mode
# tests_run(showSuccess = TRUE, debugMode = TRUE)

##tests_run()

#### eventual details on succesful tests
myTest <- tests_run(showSuccess = FALSE, debugMode = FALSE)



#### gives version information
versionInfo()

if (myTest$ok) message('everything is ok ', versionInfo()$versionCode, ', built ', versionInfo()$built)

