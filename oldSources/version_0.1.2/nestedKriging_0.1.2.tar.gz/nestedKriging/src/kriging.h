
#ifndef KRIGING_HPP
#define KRIGING_HPP

//===============================================================================
// unit containing tools for Linear Solvers and kriging Solvers
// Classes:
// ChosenSolver, KrigingPredictor , ChosenPredictor
//===============================================================================

#include "common.h"

namespace nestedKrig {

//============================== Linear Solvers
// choice of solver for linear systems (e.g. Cholesky / Inversion of Cov matrix / linear solver)
// please choose by setting: using ChosenSolver = (YourChosenClass) ; (see below)
// solve matrix equation K * alpha = k in alpha

struct SolverChoice { enum Family {InvSympd=0, Cholesky=1, Solve=2}; };
#define CHOSEN_SOLVER 2

template <int SOLVER>
struct LinearSolver { };

template <>
struct LinearSolver<SolverChoice::InvSympd> {
  static void findWeights(const arma::mat& K, const arma::mat& k, arma::mat& alpha)  {
    Long sizeK = K.n_rows;
    arma::mat Kinv(sizeK,sizeK);
    inv_sympd(Kinv,K);
    alpha = Kinv * k;
  }
};

template <>
struct LinearSolver<SolverChoice::Cholesky>  {
  static void findWeights(const arma::mat& K, const arma::mat& k, arma::mat& alpha)  {
    arma::mat R = chol(K);
    arma::mat z = arma::solve(arma::trimatl(R.t()), k, arma::solve_opts::fast);
    alpha = arma::solve(arma::trimatu(R),z, arma::solve_opts::fast);
  }
};

template <>
struct LinearSolver<SolverChoice::Solve>  {
  static void findWeights(const arma::mat& K, const arma::mat& k, arma::mat& alpha)  {
    alpha.set_size(K.n_rows,k.n_cols);
    //#pragma omp critical
    {  arma::solve(alpha, K, k, arma::solve_opts::fast);}
  }
};

using ChosenSolver = LinearSolver<CHOSEN_SOLVER>;

//============================================================================
// Kriging predictors: from covariances (K, k) and observations Y
// gives weights alpha, Yhat, Cov(Y, Yhat), Cov(Yhat, Yhat)

using type_Y = arma::rowvec; //previously arma::mat

class KrigingPredictor{
protected:
  const arma::mat& K;
  const arma::mat& k;
  const type_Y& Y;
  const Long q;

public:
  KrigingPredictor(const arma::mat& K, const arma::mat& k, const type_Y& Y) : K(K), k(k), Y(Y), q(k.n_cols) {}
  virtual ~KrigingPredictor() {}

  virtual void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) const=0;
};

class SimpleKrigingPredictor : public KrigingPredictor {
public:
  SimpleKrigingPredictor(const arma::mat& K, const arma::mat& k, const type_Y& Y): KrigingPredictor(K, k, Y) {
  }

  virtual void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) const {
    ChosenSolver::findWeights(K, k, weights);
    predictor = Y * weights;
    for(Long m=0;m<q;++m){ // parallelizable
      covYhatYhat[m] = covYhatY[m] = arma::dot(k.col(m),  weights.col(m));
    }
  }
};

class OrdinaryKrigingPredictor : public KrigingPredictor {
public:

  OrdinaryKrigingPredictor(const arma::mat& K, const arma::mat& k, const type_Y& Y): KrigingPredictor(K,k,Y)  {
  }

  virtual void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) const {
    Long sizeK = K.n_rows;
    arma::mat Kinv(sizeK,sizeK);
    inv_sympd(Kinv,K);
    arma::rowvec one_t(sizeK);
    one_t.ones();
    arma::rowvec tmp1 = (1-one_t*Kinv*k)/arma::accu(Kinv);

    arma::mat k_OK(sizeK,q);
    for(Long m=0;m<q;++m) k_OK.col(m) = k.col(m) + tmp1(m);
    weights = Kinv*k_OK;
    predictor = Y * weights;

    for(Long m=0;m<q;m++){ // parallelizable
      covYhatY[m] = arma::dot( k.col(m), weights.col(m) );
      covYhatYhat[m] = arma::dot( k_OK.col(m), weights.col(m) );
    }
  }
};

class ChosenPredictor {
  KrigingPredictor* krigingPredictor = nullptr;

public:
  ChosenPredictor(const arma::mat& K, const arma::mat& k, const type_Y& Y, bool ordinaryKriging)  {
    if (ordinaryKriging) {krigingPredictor=new OrdinaryKrigingPredictor(K, k, Y); }
    else {krigingPredictor=new SimpleKrigingPredictor(K, k, Y); }
  }

  ~ChosenPredictor() {
    delete krigingPredictor;
  }

  void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) {
    krigingPredictor->fillResults(weights,predictor,covYhatY,covYhatYhat);
  }

  //-------------- this object is not copied or moved, check pointer copy if needed
  ChosenPredictor (const ChosenPredictor &) = delete;
  ChosenPredictor& operator= (const ChosenPredictor &) = delete;
  ChosenPredictor (ChosenPredictor &&) = delete;
  ChosenPredictor& operator= (ChosenPredictor &&) = delete;
};



}
#endif /* KRIGING_HPP */

