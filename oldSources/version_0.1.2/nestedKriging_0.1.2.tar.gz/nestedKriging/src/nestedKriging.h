
#ifndef NESTEDKRIGING_HPP
#define NESTEDKRIGING_HPP

//===============================================================================
// unit used for computing the nested Kriging predictions
// classes:
// GlobalOptions, Parallelism, ScaledData, Output, Algo, AlgoZones
//===============================================================================
// note: all exceptions are collected in nestedKriging.cpp => can use throw when catch

//#define SKIPALGOZONE //uncomment to skip algo Zone

//========================================================== OpenMP =======
#if defined(_OPENMP)
#include <omp.h>
#endif

//========================================================== C++ headers ==========

#include "common.h"
#include "messages.h"
#include "covariance.h"
#include "splitter.h"
#include "kriging.h"

namespace nestedKrig {

//======================================================= Personal constants

#define CHOSEN_CHUNKSIZE 1
#define CHOSEN_SCHEDULE dynamic

//======================================================= Personal data types

using NuggetVector = Covariance::NuggetVector;

//========================================================== Developer Options

class GlobalOptions {
public:
  enum class Option : unsigned int {implAlgoB=0, numThreadsOther=1, otherOption=2, _count_=3 };
  const std::vector<std::string> optionNames { "implAlgoB", "numThreadsOther", "otherOption"};
  const std::vector<Option> allOptions { Option::implAlgoB, Option::numThreadsOther, Option::otherOption };

private:
  static const int defaultOptionValue=1;

  std::vector<int> optionValues {};

  void setDefaultValues() {
    Long totalNumberOfOptions = static_cast<Long>(Option::_count_)+1;
    optionValues.resize(totalNumberOfOptions);
    for(auto& option: optionValues) option = defaultOptionValue;
  }

public:

  GlobalOptions()  {
    setDefaultValues() ;
    }

  void setOptions(const Rcpp::IntegerVector& userChoices) {
    setDefaultValues();
    Long numberOfUserOptions  = static_cast<Long>(userChoices.size());
    for (Long i = 0; i < numberOfUserOptions; ++i) optionValues[i] = userChoices(i);
  }

  int getOptionValue(const Option option) const {
    int optionIndex= static_cast<int>(option);
    return optionValues[optionIndex];
  }

  std::string getOptionString(const Option option) const {
    int optionIndex= static_cast<int>(option);
    return optionNames[optionIndex];
  }

  std::string str() const {
    std::ostringstream oss;
    oss << " => developer options: ";
    for(auto& option: allOptions) oss << getOptionString(option) << " = " << getOptionValue(option) << ". ";
    return oss.str();
  }
};

GlobalOptions options; // Global Variable

//========================================================== Parallelism
// class giving informations on parallel programming settings
// when threads number are set to 0, defaults are employed (nb of cores for inner context)

class Parallelism {

  std::array<int, 3> threadsNumberByContext{ {1, 1, 1} };
  std::array<int, 3> boundedThreadsNumberByContext{ {1, 1, 1} };

  template<int context>
  int defaultNumThreads() { return 1; }

public:
  enum Contexts {outerContext=0, innerContext=1, residualContext=2};

  Parallelism() {
  set_nested(0);
  }

  static void set_nested(int value) {
    #if defined(_OPENMP)
        omp_set_nested(value);
    #endif
  }

  template<int context>
  void setThreadsNumber(int numThreads) {
    if (numThreads<1) numThreads=Parallelism::defaultNumThreads<context>();
    threadsNumberByContext[context]=numThreads;
    boundedThreadsNumberByContext[context]=numThreads;
  }

  template<int context>
  void boundThreadsNumber(int maxValue) {
    if (maxValue<threadsNumberByContext[context]) {
      screen.warning("a number of threads is greater than the corresponding loop size.");
      boundedThreadsNumberByContext[context]=maxValue;
    }
  }

  template<int context>
  inline int getBoundedThreadsNumber() const {
    return boundedThreadsNumberByContext[context];
  }

  template<int context>
  void switchToContext() const {
#if defined(_OPENMP)
    omp_set_num_threads(getBoundedThreadsNumber<context>());
    // to be checked: omp_set_num_threads can be called within a multithread session (in AlgoZone)
    // but this routine can only be called from the serial portions of the code ?
#endif
  }

  std::string informationString() const {
#if defined(_OPENMP)
    std::ostringstream oss;
    oss << " => Parallelism is activated, Your system have: ";
    oss << omp_get_num_procs() << " logical cores. \n";
    return oss.str();
#else
    return " *** NO PARALLELISM ACTIVATED *** ";
#endif
  }
};

#if defined(_OPENMP)
template<>
int Parallelism::defaultNumThreads<Parallelism::innerContext>() {
  return omp_get_thread_num();
}
#endif

//======================================================== SubModels
// structure containing all informations about submodels
// the structure is thought to free memory of unused (large) matrices after construction
// like X, x, Points(X) ...

class Submodels {

    bool noNugget(const NuggetVector& nugget) {
      if (nugget.size()==1) return (fabs(nugget[0])<1e-100);
      return (nugget.size()==0);
    }

    void createSplittedNuggets(const Splitter& splitter, const Long n, const NuggetVector& nugget) {
      try{
        splittedNuggets.resize(N);
        const Long userNuggetSize = nugget.size();
        if (noNugget(nugget)) {             // no nugget => create empty nuggets
            for(Long i=0; i<N; ++i) splittedNuggets[i]=NuggetVector{};
        } else if (userNuggetSize==1) {     // size 1 => copy the nugget in each submodel
          for(Long i=0; i<N; ++i) splittedNuggets[i]=nugget;
        } else if (userNuggetSize==n) {     // size n => split the nugget vector
            splitter.split<NuggetVector>(nugget, splittedNuggets);
        } else {                            // size<n => repeat pattern and split
            NuggetVector completedNugget(n);
            for(Long i=0; i<n; ++i) completedNugget[i] = nugget[i%userNuggetSize];
            splitter.split<NuggetVector>(completedNugget, splittedNuggets);
        }
      }
      catch(const std::exception& e) {
        screen.error("error while creating splitted nuggets", e);throw;
      }
    }

  public:
    const PointDimension d;
    const Points predictionPoints;
    const Long N, cmax;
    std::vector<Points> splittedX{};
    std::vector<arma::rowvec> splittedY{};
    std::vector<NuggetVector> splittedNuggets{};

Submodels(const arma::mat& X, const arma::mat& x, const arma::vec& Y,
          const CovarianceParameters& covParams, const Splitter& splitter, const NuggetVector& nugget)
      : d(X.n_cols),
        predictionPoints(x, covParams),
        N(splitter.get_N()), cmax(splitter.get_maxGroupSize())
         {
      const Points pointsX(X, covParams);
      splitter.split<Points>(pointsX, splittedX);
      splitter.split<arma::rowvec>(Y.t(), splittedY);
      createSplittedNuggets(splitter, X.n_rows, nugget);

      }

    // ensures no copy of this heavy object:
    Submodels (const Submodels &other) = delete;
    Submodels (Submodels &&other) = delete;
    Submodels& operator= (const Submodels &other) = delete;
    Submodels& operator= (Submodels &&other) = delete;
};

//========================================================================= output
class Output{

  template <class T>
  T empty(const T&) const {
    T emptyObject;
    return emptyObject;
  }

public:
  std::vector<double> durations;
  double totalChrono;
  std::vector<arma::mat> Knu;    // q items, each = NxN cov matrix between Mi(x)
  std::vector<arma::vec> knu;    // q items, each = Nx1 cov vector between Mi(x) and Y(x)
  std::vector<arma::vec> Yhat;   // q items, each = Nx1 prediction vector Mi(x)
  std::vector<arma::mat> alpha;  // N items, each = ni x q matrix of weights: columns give weigths for each pred point in the submodel
  arma::mat weights;             // q columns, each = Nx1 weigts between submodels (N x q matrix)
  arma::vec predmean;            // q x 1 prediction vector, pred mean for each pred point
  arma::vec predsd2;             // q x 1 prediction vector, pred var  for each pred point

  // replace enum class which cannot be used as integer template argument without cast
  struct Durations {enum durationParts { partA=0, partB=1, partC=2, total=3}; };

  Output(Long N, Long q) : durations(4, 0.0), totalChrono(0), Knu(q), knu(q), Yhat(q), alpha(N), weights(N,q), predmean(q), predsd2(q) {
    reserveMatrices(N,q);
  }

  Output() :  durations(4, 0.0), totalChrono(0), Knu{}, knu{}, Yhat{}, alpha{}, weights{}, predmean{}, predsd2{} {}

  void reserveMatrices(Long N, Long q) {
    try{
      predmean.resize(q);
      predsd2.resize(q);
      weights.set_size(N,q);
      Knu.resize(q);
      knu.resize(q);
      Yhat.resize(q);
      for(Long m=0; m<q; ++m) {
        knu[m].set_size(N);
        Yhat[m].set_size(N);
        Knu[m].set_size(N,N);
      }
    }
    catch(const std::exception& e) {
     screen.error("in reserveMatrices", e);
     throw;
    }
  }

  //copy constructor and affectation operators are used after, they are set to default's compiler ones
  Output (const Output &other) = default;
  Output& operator= (const Output &other) = default;
  Output (Output &&other) = default;
  Output& operator= (Output &&other) = default;

  Rcpp::List exportList(int outputDetailLevel=2) const {
    std::ostringstream versionInfos;
    versionInfos << VERSION_CODE  << " built " << BUILT_ID;
    return Rcpp::List::create(Rcpp::Named("mean") = predmean,
                              Rcpp::Named("sd2") = predsd2,
                              Rcpp::Named("duration_PartA") = durations[Durations::partA],
                              Rcpp::Named("duration_PartB") = durations[Durations::partB],
                              Rcpp::Named("duration_PartC") = durations[Durations::partC],
                              Rcpp::Named("duration_ABC")   = durations[Durations::total],
                              Rcpp::Named("duration_Total") = totalChrono,
                              Rcpp::Named("sourceCode") = versionInfos.str(),
                              Rcpp::Named("weights") = (outputDetailLevel>=1)?weights:empty(weights),
                              Rcpp::Named("Yhat") = (outputDetailLevel>=1)?Yhat:empty(Yhat),
                              Rcpp::Named("K_M") = (outputDetailLevel>=2)?Knu:empty(Knu),
                              Rcpp::Named("k_M") = (outputDetailLevel>=2)?knu:empty(knu));
  }
};

//================================================================================== Algo
// Algorithm with only one layer

class Algo {
  //input objects (cf. end of the unit for a description):
  const Parallelism& parallelism;
  const PointDimension d;
  const double sd2;
  const bool ordinaryKriging;
  std::string tag;
  const int verboseLevel;

  //built in construction:
  const CovarianceParameters covParam;
  const Submodels submodels;
  const Covariance kernel;
  const Long n, q, N;
  Chrono chrono;

  //results of the algorithm
  Output out;

  template <int ShowProgress>
  void run() {
    try{
    chrono.start();
    firstLayer_partA<ShowProgress>();
    out.durations[Output::Durations::partA] = chrono.durationStep();
    firstLayer_partB<ShowProgress>();
    out.durations[Output::Durations::partB] = chrono.durationStep();
    agregateFirstLayer<ShowProgress>();
    out.durations[Output::Durations::partC] = chrono.durationStep();
    out.durations[Output::Durations::total] = chrono.durationSinceStart();
    }
    catch(const std::exception& e) {
      screen.error("in Algo.run", e);
      throw;
    }
  }

public:
  Algo(const Parallelism& parallelism, const arma::mat& X, const arma::vec& Y, const Splitter& splitter, const arma::mat& x, const arma::vec& param,
       const double sd2, const bool ordinaryKriging, const std::string& covType, const std::string& tag, const int verboseLevel, const NuggetVector& nugget)
      : parallelism(parallelism), d(X.n_cols), sd2(sd2), ordinaryKriging(ordinaryKriging), tag(tag),
      verboseLevel(verboseLevel),
      covParam(d, param, sd2, covType),
      submodels(X, x, Y, covParam, splitter, nugget),
      kernel(covParam),
      n(X.n_rows), q(x.n_rows), N(submodels.N), chrono(tag),
      out(N,q)
  {
    constexpr int showProgress=1, noShowProgress=0;
    if (verboseLevel>0) run<showProgress>();
    else run<noShowProgress>();
  }

template <int ShowProgress>
void firstLayer_partA() {
    chrono.print("Part A, first layer, prediction for each group: starting...");
    ProgressBar<ShowProgress> progressBar(chrono, N, verboseLevel);
    parallelism.switchToContext<Parallelism::innerContext>();
    #pragma omp parallel for schedule(CHOSEN_SCHEDULE, CHOSEN_CHUNKSIZE)// Main label (A)
    for(Long i=0; i<N; ++i) {
      Long ni= submodels.splittedX[i].size(), q= submodels.predictionPoints.size();
      arma::mat K(ni, ni), k(ni, q);
      kernel.fillAllocatedCorrMatrix(K, submodels.splittedX[i], submodels.splittedNuggets[i]);
      kernel.fillAllocatedCrossCorrelations(k, submodels.splittedX[i], submodels.predictionPoints);
      ChosenPredictor krigingPredictor(K, k, submodels.splittedY[i], ordinaryKriging);

		  arma::rowvec vec_Yhat(q);
		  std::vector<double> covYhatY(q);
		  std::vector<double> covYhatYhat(q);

  		  krigingPredictor.fillResults(out.alpha[i], vec_Yhat, covYhatY, covYhatYhat);

      for(Long m=0;m<q;++m){ // parallelizable
        out.Yhat[m](i) = vec_Yhat[m];
        out.knu[m](i) =covYhatY[m];
        out.Knu[m](i,i) = covYhatYhat[m];
      }
      progressBar.next();
    }
    chrono.print("Part A, first layer, prediction for each group: done.");
  }

template <int ShowProgress>
inline void firstLayer_partB_givenij(ProgressBar<ShowProgress>& progressBar, Long i, Long j) {
  arma::mat Kij(submodels.splittedX[i].size(), submodels.splittedX[j].size());
  kernel.fillAllocatedCrossCorrelations(Kij, submodels.splittedX[i], submodels.splittedX[j]);
  arma::mat Mi =  Kij * out.alpha[j];
  for(Long m=0;m<q;++m) out.Knu[m].at(i,j) = out.Knu[m].at(j,i) = arma::dot(out.alpha[i].col(m), Mi.col(m));
  progressBar.next();
}

template <int ShowProgress>
void firstLayer_partB_v0() {
  const Long wmax=N*(N-1)/2;
  chrono.print("Part B, first layer, covariances inter-groups: starting...");
  ProgressBar<ShowProgress> progressBar(chrono, wmax, verboseLevel);
  parallelism.switchToContext<Parallelism::innerContext>();
  #pragma omp parallel for schedule(CHOSEN_SCHEDULE, CHOSEN_CHUNKSIZE) collapse(2)
  for(Long i=0; i<N; ++i)
    for(Long j=1; j<N; ++j) {
      if (i<j) {
        arma::mat Kij(submodels.splittedX[i].size(), submodels.splittedX[j].size());
        kernel.fillAllocatedCrossCorrelations(Kij, submodels.splittedX[i], submodels.splittedX[j]);
        arma::mat Mi =  Kij * out.alpha[j];
        for(Long m=0;m<q;++m) out.Knu[m].at(i,j) = out.Knu[m].at(j,i) = arma::dot(out.alpha[i].col(m), Mi.col(m));
        progressBar.next();
      }
    }
    chrono.print("Part B, first layer, covariances inter-groups: done.");
}

template <int ShowProgress>
void firstLayer_partB_v1() {
  const Long wmax = N*(N-1)/2;
  chrono.print("Part B (v1_new), first layer, covariances inter-groups: starting...");
  ProgressBar<ShowProgress> progressBar(chrono, wmax, verboseLevel);
  parallelism.switchToContext<Parallelism::innerContext>();
#pragma omp parallel for schedule(CHOSEN_SCHEDULE, CHOSEN_CHUNKSIZE)// Main label (B).
  for(Long w=0; w<wmax; ++w) {
    long i = w%N, j = w/N; //can use std::div
    if(i<=j) { i = N - i - 1; j = N - j - 2; }
    arma::mat Kij(submodels.splittedX[i].size(), submodels.splittedX[j].size());
    kernel.fillAllocatedCrossCorrelations(Kij, submodels.splittedX[i], submodels.splittedX[j]);
    arma::mat Mi =  Kij * out.alpha[j];
    for(Long m=0;m<q;++m) out.Knu[m].at(i,j) = out.Knu[m].at(j,i) = arma::dot(out.alpha[i].col(m), Mi.col(m));
    progressBar.next();

  }
  chrono.print("Part B (v1_new), first layer, covariances inter-groups: done.");
}

template <int ShowProgress>
  void firstLayer_partB() {
    long choixImplementation=options.getOptionValue(GlobalOptions::Option::implAlgoB);
    switch (choixImplementation)  {
    case 1:
      firstLayer_partB_v1<ShowProgress>(); break;
    default:
      firstLayer_partB_v0<ShowProgress>(); break;
    }
  }

  template <int ShowProgress>
  void agregateFirstLayer() {
    chrono.print("Part C, aggregation first layer: starting...");
    parallelism.switchToContext<Parallelism::innerContext>(); //A peaufiner car NbThreads limités par N
    #pragma omp parallel for schedule(CHOSEN_SCHEDULE, CHOSEN_CHUNKSIZE)// Main label (C)
    for(Long m = 0; m < q; ++m) {
      arma::mat alpha(N,1);
      ChosenSolver::findWeights(out.Knu[m], out.knu[m], alpha);
      out.weights.col(m) = alpha;
      out.predmean(m) = arma::dot( alpha, out.Yhat[m] );
      out.predsd2(m) = std::max(0. , sd2* (1 - arma::dot(alpha, out.knu[m])));
    }
    chrono.print("Part C, aggregation first layer: done.");
  }

  Output output() const {
    return out; //returns a (movable) copy, used in AlgoZone
  }

  Rcpp::List exportList(int outputDetailLevel=0) const {
    return out.exportList(outputDetailLevel);
  }

};
//======================= Launch independent algorithms on separate prediction zones

class AlgoZones {

  // algo inputs
  const Parallelism& parallelism;
  const arma::mat &X, &x;
  const arma::vec &Y, &param;
  const Splitter& splitter;
  const bool ordinaryKriging;
  const std::string covType;
  const Long NbZones, n, q;
  const PointDimension d;
  const double sd2;
  const std::string tagAlgo;
  const int verboseLevel;
  const int outputDetailLevel;

  // splitted objects
  Splitter splitterZone{};
  std::vector<arma::mat> splittedx{};
  std::vector<Output> splittedOutput{};
  Output mergedOutput{};
  const NuggetVector& nugget;
  Chrono chrono;

  void updateDurations() {
    for(int part=0; part<= Output::Durations::total; ++part) {
      double maxDuration=0.0;
      for(Long z=0; z<NbZones; ++z) maxDuration = std::max(maxDuration, splittedOutput[z].durations[part]);
      mergedOutput.durations[part]=maxDuration;
    }
    mergedOutput.totalChrono = chrono.durationSinceStart();
  }

  void mergeOutputs(const Splitter& splitterZone) {
    chrono.print("merge outputs: starting...");
    std::vector<arma::vec> splittedpredmean(NbZones), splittedpredsd2(NbZones);
    std::vector<std::vector<arma::vec> > splittedknu(NbZones), splittedYhat(NbZones);
    std::vector<std::vector<arma::mat> > splittedKnu(NbZones);
    for(Long i=0; i<NbZones; ++i) {
      splittedpredmean[i] = splittedOutput[i].predmean;
      splittedpredsd2[i] = splittedOutput[i].predsd2;
      if (outputDetailLevel>=1) splittedYhat[i]= splittedOutput[i].Yhat;
      if (outputDetailLevel>=2) splittedknu[i] = splittedOutput[i].knu;
      if (outputDetailLevel>=2) splittedKnu[i] = splittedOutput[i].Knu;
    }
    splitterZone.merge<arma::vec>(splittedpredmean, mergedOutput.predmean);
    splitterZone.merge<arma::vec>(splittedpredsd2, mergedOutput.predsd2);
    if (outputDetailLevel>=1) splitterZone.merge<std::vector<arma::vec> >(splittedYhat, mergedOutput.Yhat);
    if (outputDetailLevel>=2) splitterZone.merge<std::vector<arma::vec> >(splittedknu, mergedOutput.knu);
    if (outputDetailLevel>=2) splitterZone.merge<std::vector<arma::mat> >(splittedKnu, mergedOutput.Knu);

    chrono.print("merge outputs: done.");
  }

  template <typename T>
  T copy(T& object) { return object;}

public:
AlgoZones(const Parallelism& parallelism, const Long NbZones, const arma::mat& X, const arma::vec& Y, const Splitter& splitter, const arma::mat& x, const arma::vec& param,
          const double sd2, const bool ordinaryKriging, const std::string& covType, const std::string& tagAlgo,
          const int verboseLevel, const int outputDetailLevel, const NuggetVector& nugget)
      :  parallelism(parallelism), X(X), x(x), Y(Y), param(param), splitter(splitter), ordinaryKriging(ordinaryKriging), covType(covType),
       NbZones(NbZones), n(X.n_rows), q(x.n_rows), d(X.n_cols), sd2(sd2), tagAlgo(tagAlgo), verboseLevel(verboseLevel), outputDetailLevel(outputDetailLevel), nugget(nugget),
       chrono("general zone")
       {
    run();
  }

  void run() {
    try {
    chrono.start();
    splitterZone.setModuloSplitScheme(q, NbZones);
    splitterZone.split<arma::mat>(x, splittedx);
    splittedOutput.resize(NbZones);

    // preallocation of splittedoutput content useless, done with further affectations splittedOutput[z] =...?
    // for(Long z=0; z<NbZones; ++z) splittedOutput[z].reserveMatrices(splitter.get_N(),splittedx[z].size());

    parallelism.switchToContext<Parallelism::outerContext>();
    #pragma omp parallel for schedule(static, CHOSEN_CHUNKSIZE)
    for(Long z=0; z<NbZones; ++z) {
        std::string tag = tagAlgo + " zone=" + std::to_string(z);
        Algo* algo=new Algo(parallelism, X, Y, splitter, splittedx[z], param, sd2, ordinaryKriging, covType, tag, verboseLevel, copy(nugget));
        splittedOutput[z] = algo->output(); //move assignement
        delete algo;
        }
    mergeOutputs(splitterZone);
    updateDurations();
    chrono.print("finished.");
    }
    catch(const std::exception& e) {
      screen.error("in Algo Zone", e);
      throw;
    }
  }

  Output output() const {
    return mergedOutput; // returns a copy
  }

 Rcpp::List exportList(int outputDetailLevel=0) const {
   return mergedOutput.exportList(outputDetailLevel);
   }
};

Rcpp::List nested_kriging(
const arma::mat& X,
const arma::vec& Y,
const ClusterVector& clusters,
const arma::mat& x,
const std::string covType,
const arma::vec& param,
const double sd2,
const bool ordinaryKriging=false,
const std::string tagAlgo="",
long numThreadsZones=0,
long numThreads=0,
const int verboseLevel=10,
const int outputDetailLevel=1,
const Rcpp::IntegerVector optionsVector = Rcpp::IntegerVector::create(0),
const arma::vec nugget =  Rcpp::NumericVector::create(0.0)
) {

screen.showMessages = (verboseLevel>=1);
screen.showWarnings = (verboseLevel>=0);

options.setOptions(optionsVector);

Splitter splitter(clusters);
Long q=x.n_rows, N=splitter.get_N();


Parallelism parallelism;
screen.print(parallelism.informationString(), tagAlgo);

parallelism.setThreadsNumber<Parallelism::outerContext>(numThreadsZones);
parallelism.boundThreadsNumber<Parallelism::outerContext>(q);

parallelism.setThreadsNumber<Parallelism::innerContext>(numThreads);
Long maxThreadsGroup = std::max(N*(N-1)/2, static_cast<Long>(1));
parallelism.boundThreadsNumber<Parallelism::innerContext>(maxThreadsGroup);

//parallelism.setThreadsNumber<Parallelism::residualContext>(options.getOptionValue(GlobalOptions::Option::numThreadsOther));

Long threadsZone=static_cast<Long>(numThreadsZones), threadsGroups=static_cast<Long>(numThreads);
if (threadsZone>q) screen.warning("as numThreadsZones>q, algorithm Zone will not use all available threads");
if (threadsGroups>N) screen.warning("as numThreads>N, algorithm (part A) will not use all available threads");
if (threadsGroups>maxThreadsGroup) screen.warning("as numThreads>N(N-1)/2, algorithm (part B) will not use all available threads");

#if defined(SKIPALGOZONE)
  const long NbZones=1;
#else
  const long NbZones = parallelism.getBoundedThreadsNumber<Parallelism::outerContext>();
#endif

if (NbZones>1) {
      Parallelism::set_nested(1);
      AlgoZones algoZ(parallelism, NbZones, X, Y, splitter, x, param, sd2, ordinaryKriging, covType, tagAlgo, verboseLevel, outputDetailLevel, nugget);
      return algoZ.exportList(outputDetailLevel);
    } else {
      Algo algo(parallelism, X, Y, splitter, x, param, sd2, ordinaryKriging, covType, tagAlgo, verboseLevel, nugget);
      return algo.exportList(outputDetailLevel);
    }
}

}//end namespace
#endif /* NESTEDKRIGING_HPP */

// conventions for objects
// X: design matrix, n x d
// Y: response vector, size n
// clusters: vector containing the group number of all n points
// x: matrix of points where the prediction is computed: q x d
// covType: the covariance name
// param: vector of parameters of the considered covariance
// sd2: variance
// OrdinaryKriging: boolean, true= use Simple Kriging, false=use Ordinary Kriging
// tagAlgo: string displayed with messages, to identify algorithm run
// numThreadsZones: number of Threads among prediction points (should be <q, recommended= 1)
// numThreads: number of Threads among groups (shoud be <N)

// deduced parameters:
// gpsize: vector with the sizes of each group, deduced from gp
// N: total number of groups (no more used, deduced from gp)
// q: number of points where a prediction is computed = x.n_rows
// n: number of observations = X.n_rows
// d: dimension = X.n_cols = x.n_cols

// conventions for loop indexes
// obs = 0...n-1 , n number of observations
// k   = 0...d-1 , d dimension
// i   = 0...N-1 , N number of groups, first loop
// j   = 0...N-1 , N number of groups, second loop
// m   = 0...q-1 , q number of prediction points
// r   = 0...groupSize[i]-1, row/elt iterator in group i (class Splitter only)
// z   = 0...NbZones-1, zone iterator when prediction points x are splitted into NbZones zones
// w   = 0...N*N-1 , fuse of the two loops for i, for j

