


setNumThreadsBLAS <-function(numThreadsBLAS=1, showMessage=TRUE) {
  ##library(RhpcBLASctl)
  RhpcBLASctl::blas_set_num_threads(numThreadsBLAS)
  if (showMessage) {  message("linear algebra libray BLAS threads set to ", numThreadsBLAS) }
}

nestedKriging <- function(X, Y, clusters, x, covType, param, sd2, krigingType="simple", tagAlgo = "", numThreadsZones = 1L, numThreads = 16L, verboseLevel = 10L, outputLevel = 0L, numThreadsBLAS = 1L, globalOptions= as.integer( c(0))) {

  ################################################### basic check of input arguments validity

  if (class(X)!="matrix") stop("'X' must be a matrix")
  if ((nrow(X)<1)||(ncol(X)<1)) stop("'X' must have at least one raw and one column")
  if (!is.numeric(X)) stop("'X' must contain numeric values")
  if (!all(is.finite(X))) stop("'X' must contain finite values")

  if(!is.numeric(Y)) stop("'Y' must be a vector of numeric values")
  if (length(Y)<1) stop("'Y' must contain at least one value")
  if (!all(is.finite(Y))) stop("'Y' must contain finite values")
  if(!(length(Y)==nrow(X))) stop("'Y' must have the same length as the number of rows in 'X'")

  if (!is.numeric(clusters)) stop("'clusters' must be a vector of integer values")
  if (length(clusters)<1) stop("'clusters' must contain at least one value")
  if (!all(is.finite(clusters))) stop("'clusters' must contain finite values")
  if (!isTRUE(all.equal(clusters, as.integer(clusters)))) stop("'clusters' must contain integer values")
  if (!all(clusters>=0)) stop("'clusters' must contain nonnegative integer values")
  if (!(length(clusters)==nrow(X))) stop("'clusters' must have the same length as the number of rows in X")
  clusters <- as.integer(round(clusters,0))

  if (class(x)!="matrix") stop("'x' must be a matrix")
  if ((nrow(x)<1)||(ncol(x)<1)) stop("'x' must have at least one raw and one column")
  if (!is.numeric(x)) stop("'x' must contain numeric values")
  if (!all(is.finite(x))) stop("'x' must contain finite values")
  if (ncol(X)!=ncol(x)) stop("error: 'X' and 'x' must have the same number of columns")

  validCovType = c("gauss", "matern5_2", "matern3_2", "exp", "powexp", "white_noise")
  if(class(covType)!="character") stop("'covType' must be one of the following:", paste(validCovType, collapse=", ") )
  if(!(covType) %in% validCovType) stop("'covType' must be one of the following:", paste(validCovType, collapse=", ") )

  if(!is.numeric(param)) stop("'param' must be a vector of numeric values")
  if (!all(is.finite(param))) stop("'param' must contain finite values")
  if (length(param)<1) stop("'param' must contain at least one value")
  if(!(length(param)==ncol(X))) stop("'param' must have the same length as the number of columns in X")

  validKrigingType = c("simple", "ordinary")
  if(class(krigingType)!="character") stop("'krigingType' must be one of the following:", paste(validKrigingType, collapse=", ") )
  if(!(krigingType) %in% validKrigingType) stop("'krigingType' must be one of the following:", paste(validKrigingType, collapse=", ") )

  if (!(is.character(tagAlgo))) stop("'tagAlgo' must be a character string")

  integerList=list(numThreadsZones, numThreads, numThreadsBLAS, verboseLevel, outputLevel)
  integerListStr=list("'numThreadsZones'", "'numThreads'", "'numThreadsBLAS'", "'verboseLevel'", "'outputLevel'")
  for(i in 1:length(integerList)) {
    if (!(is.numeric(integerList[[i]]))) stop(integerListStr[[i]], " must be an integer numeric value")
    if (!(length(integerList[[i]])==1)) stop(integerListStr[[i]], " must be ONE integer")
    if (abs(integerList[[i]]-as.integer(integerList[[i]]))>1e-5) stop(integerListStr[[i]], " must be an integer")
  }

  numThreadsZones <- as.integer(round(numThreadsZones,0))
  numThreads <- as.integer(round(numThreads,0))
  numThreadsBLAS <- as.integer(round(numThreadsBLAS,0))
  verboseLevel <- as.integer(round(verboseLevel,0))
  outputLevel <- as.integer(round(outputLevel,0))

  if (numThreadsZones<1) stop("'numThreadsZones' must be at least 1")
  if (numThreads<1) stop("'numThreads' must be at least 1")
  if (numThreadsBLAS<1) stop("'numThreadsBLAS' must be at least 1")

  if(!is.numeric(globalOptions)) stop("'globalOptions' must be a vector of numeric values")
  if (length(globalOptions)<1) stop("'globalOptions' must contain at least one value")
  if (!all(is.finite(globalOptions))) stop("'globalOptions' must contain finite values")

  ################################################### Set BLAS Threads and launch algo

  setNumThreadsBLAS(numThreadsBLAS, FALSE)
  #.Call('_nestedKriging_nestedKrigingDirect', PACKAGE = 'nestedKriging', X, Y, clusters, x, covType, param, sd2, krigingType, tagAlgo, numThreadsZones, numThreads, verboseLevel, outputLevel, globalOptions)
  .Call('_nestedKriging_nestedKrigingDirect', X, Y, clusters, x, covType, param, sd2, krigingType, tagAlgo, numThreadsZones, numThreads, verboseLevel, outputLevel, globalOptions)
}

