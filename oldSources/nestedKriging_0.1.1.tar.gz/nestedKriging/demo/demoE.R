rm(list=ls(all=TRUE))

#############################################
#                                           #
#  demoE.R : tests and version information  #
#                                           #
#############################################

#########################################
#### library installation (you might need to install Rtools before)
#### in RStudio:
#### go to menu Tools, Install Package...,
#### select Install from Package Archive File,
#### select nestedKriging_xxx.tar.gz

#########################################
#### gives version informations

library(nestedKriging)

versionInfo()

#########################################
#### launch tests with details on failures only

tests_run()

#### eventual details on succesful tests
myTest <- tests_run(showSuccess = TRUE)

if (myTest$ok) message('everything is ok')

#########################################
#### manual tests

caseStudyOne <- tests_getCaseStudy(1, "gauss")

myResults <- tests_getCodeValues(1, "gauss", forceSimpleKriging = TRUE)

#### to be compared with other implementations
