
#ifndef SANDBOX_HPP
#define SANDBOX_HPP

//===============================================================================
// unit used for developper code trials, before insertion in main code
// can be commented in released versions of the package
//===============================================================================

/*

//========================================================== R - Armadillo =======
#if defined(_OPENMP)
#include <omp.h>
#endif

#define ARMA_NO_DEBUG //avoids bounds check for Armadillo objects (1-2% faster)
#include <RcppArmadillo.h>
// [[Rcpp::plugins(openmp, cpp11)]]
using namespace Rcpp;
//========================================================== C++ headers ==========

#include <cmath>
#include <stdio.h>
//#include <cstdio>
#include <string>
#include <vector>
#include <sstream>

#include <chrono>

namespace sandBox {

using Long = std::size_t;

template <class ContainerType> // for vector types by default
struct VectorView : public ContainerType {
  using ValueType = typename ContainerType::value_type;

  ContainerType* data_ptr;
  const Long n_cols;

  VectorView(ContainerType& data, const Long contentSize) : data_ptr(&data), n_cols(contentSize) {}

  ValueType operator[](const Long i) { return (*data_ptr)[i]; }

  void resize(const Long i) { data_ptr->resize(i); }
};

template <> // for arma::mat
struct VectorView<arma::mat> {
  arma::mat* data_ptr;
  const Long n_cols;
  VectorView(arma::mat& data, Long contentSize) : data_ptr(&data), n_cols(contentSize) {}

  arma::subview_row<double> operator[](const Long i) { return data_ptr->row(i); }

  void resize(const Long i) { data_ptr->resize(i, n_cols); }
};


template <> // for const arma::mat
struct VectorView<const arma::mat> {
  typedef std::size_t Long;
  const arma::mat& data;
  const Long contentSize;
  VectorView(const arma::mat& data, Long contentSize) : data(data), contentSize(contentSize) {}

  const arma::subview_row<double> operator[](const Long i) { return data.row(i); }
};

void essaiVectorView() {
#pragma omp critical
{
  // chercher overload std::vector
  std::vector<double> myvec = {0.1, 1.1, 2.1, 3.1, 4.1, 5.1};
  VectorView<std::vector<double> > vecView(myvec, 1);
  std::cout<< vecView[3] << std::endl;
 // vecView[3] = vecView[1];
  std::cout<< vecView[3] << std::endl;
  std::cout<< myvec[3] << std::endl;

  std::cout<< std::endl << std::endl;

  const long d=7;
  arma::mat X(d,d); X.randu();
  const arma::mat Xconst = X + 1.0;
  std::cout << "X initial" << std::endl;
  X.print();
  std::cout << std::endl;

  std::cout<< std::endl << std::endl;

  VectorView<arma::mat> Xview(X, d);
  Xview[1] = Xview[0];
  Xview.resize(3);

  std::cout << "X modifié" << std::endl;
  std::cout<< std::endl << std::endl;

  X.print();
  std::cout << std::endl;
  std::cout<< std::endl << std::endl;

  VectorView<const arma::mat> Xconstview(Xconst, d);

  std::cout << "ligne X " << std::endl;
  Xconstview[1].print();
  std::cout << std::endl;
}
}

}//end namespace

*/

#endif /* SANDBOX_HPP */

