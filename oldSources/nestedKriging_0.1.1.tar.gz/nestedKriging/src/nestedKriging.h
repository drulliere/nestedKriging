
#ifndef NESTEDKRIGING_HPP
#define NESTEDKRIGING_HPP

//#define USECOMPACTSTORAGE //uncomment to use compact storage

//========================================================== R - Armadillo =======
#if defined(_OPENMP)
#include <omp.h>
#endif

#define ARMA_NO_DEBUG //avoids bounds check for Armadillo objects (1-2% faster)
#include <RcppArmadillo.h>
// [[Rcpp::plugins(openmp, cpp11)]]
using namespace Rcpp;
//========================================================== C++ headers ==========

#include <cmath>
#include <stdio.h>
//#include <cstdio>
#include <string>
#include <vector>
#include <sstream>

#include <chrono>

#include "sandBox.h"

namespace nestedKrig {

//======================================================= Personal constants
#define VERSION_CODE "nestedKriging v0.1.1"
#define BUILT_ID 21
#define INTERFACE_VERSION 3

#define CHUNKSIZE 1
#define SCHEDULE dynamic

//======================================================= Personal minimal vector

class CompactMatrix {
  // minimal vector<vector<double> > implementation in order to
  // . minimize the storage footprint, size O(n*d) vs vector of vectors size O(n*(3+d))
  // . store in contiguous area to ease cache usage (useful?)
  // . isolate from other memory cache lines to reduce false sharing when pad>0 (useful?)
  using size_t = std::size_t;
  static const size_t pad=16; //one cache line = 64 bytes = 8 double of 8 bytes each
  size_t _nrows, _ncols;
  //double* __restrict _datapad; //__restrict: access not supposed to refer to the same point
  double* _datapad;
  std::vector<double*> linePointers;

public:
  CompactMatrix() : _nrows(0), _ncols(0), _datapad(NULL) { }

  explicit CompactMatrix(const CompactMatrix& other) : _nrows(0), _ncols(0) {
    operator=(other);
  }

  size_t n_cols() const { return _ncols; }

  size_t n_rows() const { return _nrows; }

  size_t size() const { return _nrows; } // size as in vector of vectors, used in fillCorrMatrix

  void operator=(const CompactMatrix& other) {
    set_size(other.n_rows(), other.n_cols());
    const size_t datasize = _nrows*_ncols;
    const double* otherdata = other[0];
    std::memcpy(_datapad, otherdata, datasize*sizeof(double));
  }

  void copyLine(const size_t index, const double* lineToCopy) {
    std::memcpy(_datapad+_ncols*index, lineToCopy, _ncols*sizeof(double));
  }

  const double* operator[](const size_t index) const noexcept {
    return linePointers[index];
  }

  void set_size(const size_t rows, const size_t cols) {
    if (_nrows!=0) delete[] (_datapad-pad);
    _nrows=rows;
    _ncols = cols;
    double* _data = new double[pad+_ncols*_nrows+pad];
    _datapad=_data+pad;
    linePointers.resize(_nrows);
    for(size_t k=0; k<_nrows; ++k) linePointers[k] = _datapad+_ncols*k;
  }

  void setValue(const size_t row, const size_t col, const double value) {
    linePointers[row][col]=value;
  }

  ~CompactMatrix() {
  if (_nrows!=0) delete[] (_datapad-pad);
  _nrows=0;
  }
};

//======================================================= Personal data types

using PointDimension = std::size_t;
using Long = std::size_t ;

using Double = long double;
using ScaledParameters = std::vector<Double> ;

//------------choice for design points storage:

#if defined(USECOMPACTSTORAGE)
  using ScaledPoint = const double* ;
  using ScaledPoints = CompactMatrix;
#else
  using ScaledPoint = std::vector<double>; //arma::vec also acceptable, need [], resize(), copy and =
  using ScaledPoints = std::vector<ScaledPoint>;
#endif

//======================================================= MatrixView
// MatrixView gives a unified access to some functions, for several possible containers :
// std::vector<std::vector<double> >, arma::mat, CompactMatrix, arma::vec etc.
// to be relaced by a class VectorView with operator[] implementation // CHANTIER

template <class T> // for vector types by default
struct MatrixView {
  T& data;
  MatrixView(T& data) : data(data) {};

  static void identifyLines(T& objectA, const Long lineA, const T& objectB, const Long lineB) {
    objectA[lineA]=objectB[lineB];
  }

  void allocate(Long nrows, Long ncols=1) {
    data.resize(nrows);
  }

  unsigned long ncols() const {
    return 1;
  }
};

template <class T> // for const vector types
struct MatrixView<const T> {
  const T& data;
  MatrixView(const T& data) : data(data) {};

  unsigned long ncols() const {
    return 1;
  }
};

template <> // for arma::mat
struct MatrixView<arma::mat>  {

  arma::mat& data;
  MatrixView(arma::mat& data) : data(data) {};

  static void identifyLines(arma::mat& objectA, const Long lineA, const arma::mat& objectB, const Long lineB) {
    objectA.row(lineA)=objectB.row(lineB);
  }

  void allocate(const Long nrows, const Long ncols) {
    data.set_size(nrows, ncols);
  }

  void setValue(const size_t row, const size_t col, const double value) {
    data(row,col)=value;
  }

  unsigned long ncols() const {
    return data.n_cols;
  }
};


template <> // for const arma::mat
struct MatrixView<const arma::mat>  {

  const arma::mat& data;
  MatrixView(const arma::mat& data) : data(data) {};

  unsigned long ncols() const {
    return data.n_cols;
  }
};

using vectorOfvectors = std::vector<std::vector<double> >;

template <> // for vector of vectors
struct MatrixView<vectorOfvectors> {

  vectorOfvectors& data;
  MatrixView(vectorOfvectors& data) : data(data) {};

  static void identifyLines(vectorOfvectors& objectA, const Long lineA, const vectorOfvectors& objectB, const Long lineB) {
    objectA[lineA]=objectB[lineB];
  }

  void allocate(const Long nrows, const Long ncols) {
    data.resize(nrows);
    for(Long obs=0;obs<nrows;++obs) {data[obs].reserve(ncols); data[obs].resize(ncols);}
  }

  void setValue(const size_t row, const size_t col, const double value) {
    data[row][col]=value;
  }

  unsigned long ncols() const {
    return data[0].size();
  }
};

template <> // for const vector of vectors
struct MatrixView<const vectorOfvectors> {

    const vectorOfvectors& data;
    MatrixView(const vectorOfvectors& data) : data(data) {};

    unsigned long ncols() const {
      return data[0].size();
    }
};

template <> // for compactMatrix
struct MatrixView<CompactMatrix> {

  CompactMatrix& data;
  MatrixView(CompactMatrix& data) : data(data) {};

  static void identifyLines(CompactMatrix& objectA, const Long lineA, const CompactMatrix& objectB, const Long lineB) {
    objectA.copyLine(lineA, objectB[lineB]);
  }

  void allocate(const Long nrows, const Long ncols) {
    data.set_size(nrows, ncols);
  }

  void setValue(const Long row, const Long col, const double value) {
    data.setValue(row, col, value);
  }

  unsigned long ncols() const {
    return data.n_cols();
  }
};

template <> // for const compactMatrix
struct MatrixView<const CompactMatrix> {

  const CompactMatrix& data;
  MatrixView(const CompactMatrix& data) : data(data) {};

  unsigned long ncols() const {
    return data.n_cols();
  }
};

//========================================================= Screen
// class to show messages on the screen, global variable screen

class Screen {
  void printLine(const std::string& message, const std::string& prefix="") const {
    std::ostringstream oss;
    oss << prefix << message << std::endl;
    Rcpp::Rcout << oss.str(); // one << only, thread-safe print
  }

public:
  bool showMessages;
  bool showWarnings;

  Screen() : showMessages(true), showWarnings(true) {}

  void print(const std::ostringstream& message, const std::string& tag="") const {
    if (showMessages) printLine(message.str(), tag);
  }

  void print(const std::string& message, const std::string& tag="") const {
    if (showMessages) printLine(message, tag);
  }

  void warning(const std::string& message, const std::string& tag="") const {
    if (showWarnings) printLine(message, tag + " [nested kriging warning] ");
  }
};

Screen screen;

//========================================================== Developer Options

class GlobalOptions {
public:
  enum class Option : unsigned int {implAlgoB=0, numThreadsOther=1, otherOption=2, _count_=3 };
  const std::vector<std::string> optionNames { "implAlgoB", "numThreadsOther", "otherOption"};
  const std::vector<Option> allOptions { Option::implAlgoB, Option::numThreadsOther, Option::otherOption };

private:
  static const int defaultOptionValue=1;

  std::vector<int> optionValues;

  void setDefaultValues() {
    Long totalNumberOfOptions = static_cast<Long>(Option::_count_)+1;
    optionValues.resize(totalNumberOfOptions);
    for(auto& option: optionValues) option = defaultOptionValue;
  }

public:

  GlobalOptions() {
    setDefaultValues();
    }

  void set(const Rcpp::IntegerVector& userChoices) {
    setDefaultValues();
    Long numberOfUserOptions  = static_cast<Long>(userChoices.size());
    for (Long i = 0; i < numberOfUserOptions; ++i) optionValues[i] = userChoices(i);
  }

  int getOptionValue(const Option option) const {
    int optionIndex= static_cast<int>(option);
    return optionValues[optionIndex];
  }

  std::string getOptionString(const Option option) const {
    int optionIndex= static_cast<int>(option);
    return optionNames[optionIndex];
  }

  std::string str() const {
    std::ostringstream oss;
    oss << " => developer options: ";
    for(auto& option: allOptions) oss << getOptionString(option) << " = " << getOptionValue(option) << ". ";
    return oss.str();
  }

  void print(std::string tag="") const {
    screen.print(str(), tag);
  }
};

GlobalOptions globalOptions;

//========================================================== Parallelism
// class giving informations on parallel programming settings
// when threads number are set to 0, defaults are employed (nb of cores for inner context)

class Parallelism {

  std::array<int, 3> threadsNumberByContext{ {1, 1, 1} };
  std::array<int, 3> boundedThreadsNumberByContext{ {1, 1, 1} };

  template<int context>
  int defaultNumThreads() { return 1; }

public:
  enum Contexts {outerContext=0, innerContext=1, residualContext=2};

  Parallelism() {
#if defined(_OPENMP)
    omp_set_nested(1);
#endif
  }

  template<int context>
  void setThreadsNumber(int numThreads) {
    if (numThreads<1) numThreads=Parallelism::defaultNumThreads<context>();
    threadsNumberByContext[context]=numThreads;
    boundedThreadsNumberByContext[context]=numThreads;
  }

  template<int context>
  void boundThreadsNumber(int maxValue) {
    if (maxValue<threadsNumberByContext[context]) {
      screen.warning("a number of threads is greater than the corresponding loop size.");
      boundedThreadsNumberByContext[context]=maxValue;
    }
  }

   template<int context>
    inline int getBoundedThreadsNumber() const {
      return boundedThreadsNumberByContext[context];
    }

  template<int context>
  void switchToContext() const {
  #if defined(_OPENMP)
    omp_set_num_threads(getBoundedThreadsNumber<context>());
    omp_set_nested(1); //CHANTIER
  #endif
  }

  static void showInformations(std::string tag="") {
#if defined(_OPENMP)
    screen.print(" => Parallelism is activated ", tag);
    std::ostringstream line0;
    line0 << " => Your system have : " << omp_get_num_procs() << " logical cores.";
    screen.print(line0, tag);
#else
    screen.print(" *** NO PARALLELISM ACTIVATED ***", tag);
#endif
  }

  static std::string threadNumStr() {
#if defined(_OPENMP)
    std::ostringstream oss;
    oss << "thread " << omp_get_thread_num()+1  << "/" << omp_get_team_size(omp_get_level());
    return oss.str();
#else
    return "unique thread";
#endif
  }
};

#if defined(_OPENMP)
template<>
int Parallelism::defaultNumThreads<Parallelism::innerContext>() {
  return omp_get_thread_num();
}
#endif

//========================================================== Chrono
// class giving durations and elapsed times

class Chrono
{ // this part is dependent on the chosen external time library:
  typedef std::chrono::steady_clock::time_point Time;

  inline Time now() const {
    return std::chrono::steady_clock::now();
    }

  inline double duration(const Time& t1, const Time& t2) const {
    return std::chrono::duration_cast<std::chrono::duration<double>>(t2-t1).count();
    }

  // this part is independent:
  Time timeAtStart, timeAtStep, timeAtLastMessage;
  std::string chronoName;

  void setToZero() {
    timeAtStart = timeAtStep = timeAtLastMessage = now();
  }

  double durationSinceLastMessage() const {
    return duration(timeAtLastMessage, now());
  }

  std::string durationString() {
    std::ostringstream oss;
    oss.precision(2);
    oss << " " << std::fixed << durationSinceLastMessage() <<  "s  total  " << durationSinceStart() << "s ";
    return oss.str();
  }

public:
  explicit Chrono(const std::string& tag="") {
    chronoName = tag;
    setToZero();
  }

  void start() {
    setToZero();
    print("starting chrono.");
  }

  double durationSinceStart() const {
    return duration(timeAtStart, now());
  }

  double durationStep() {
    double elapsed= duration(timeAtStep, now());
    timeAtStep = now();
    return elapsed;
  }

  void print(const std::string& message) {
    if (screen.showMessages) {
      std::ostringstream oss;
      oss << " - " << std::left << std::setw(60) << std::setfill('-') << message << durationString();
      screen.print(oss, chronoName);
      timeAtLastMessage = now();
    }
  }

  void printProgression(const Long currentStep, const Long nbSteps) {
    if (screen.showMessages) {
      std::ostringstream oss;
      const Long padSize = static_cast<Long>(log10l(nbSteps))+1;
      oss << "   - " << "step " << std::setw(padSize) << currentStep << "/" << nbSteps << " " << durationString();
      oss << " ended on " << Parallelism::threadNumStr();
      screen.print(oss, chronoName);
      timeAtLastMessage = now();
    }
  }

  template <int ShowProgress>
  inline void progressBar(Long done, const Long total, const Long nbSteps) {
    if (((done*nbSteps)%total)<nbSteps) printProgression((done*nbSteps)/total, nbSteps);
  }
};

template <> // no calculation is required if there is no progress bar
inline void Chrono::progressBar<0>(Long done, Long total, Long nbSteps) {}

//========================================
template <int ShowProgress>
struct ProgressBar {
  Chrono& chrono;
  const Long total, nbSteps;
  Long done, nextTick;

  inline Long ceilRatio(Long x, Long y) const { //gives ceil(x/static_cast<double>(y))
    return 1+(x-1)/y;
  }

  ProgressBar(Chrono& chrono, const Long total, const Long nbSteps) : chrono(chrono), total(total), nbSteps(nbSteps) {
    done=0;
    nextTick = ceilRatio(total, nbSteps);
  }

  inline void next() {
    //race condition on done, nextTick: no importance, indicative progression only
    if (++done>=nextTick) { // >= in case of race condition, if == was jumped?
      Long currentStep = (done*nbSteps) / total;
      nextTick = ceilRatio((currentStep+1)*total, nbSteps);
      chrono.printProgression(currentStep, nbSteps);
   }
  }
};

template <> // no calculation is required if there is no print
struct ProgressBar<0> {
  ProgressBar(Chrono& chrono, const Long total, const Long nbSteps) {}
  inline void next() {}
};

//========================================================== CorrelationFunction
// Correlation functions
// to be applied to a data which has been rescaled (ScaledPoints)
// (in order to improve performance, lengthscales are set to 1 for rescaled data)

#define TIERS 0.333333333333333333333333333333

class CorrelationFunction {
public:
  const PointDimension d;

  CorrelationFunction(const PointDimension d) : d(d)  {
  }

  virtual double corr(const ScaledPoint& x1,const ScaledPoint& x2) const noexcept =0;
  virtual Double scaling_factor() const=0;
  virtual ~CorrelationFunction(){}
};

//-------------- White Noise
class CorrWhiteNoise : public CorrelationFunction {
public:
  CorrWhiteNoise(const PointDimension d) :
  CorrelationFunction(d)  {
  }

  virtual double corr(const ScaledPoint& x1,const ScaledPoint& x2) const noexcept {
    double s = 0.;
    for (PointDimension k = 0; k < d; ++k) s += std::fabs((x1[k] - x2[k]));
    if (s < 0.000000000000001) return(1.0);
    else return(0.);
  }

  virtual Double scaling_factor() const {
    return 1.0L;
  }
};

//-------------- Gauss
class CorrGauss : public CorrelationFunction {

public:
  CorrGauss(const PointDimension d) :
  CorrelationFunction(d)  {
  }

  double corr(const ScaledPoint& x1, const ScaledPoint& x2) const noexcept {
    double s = 0.;
    //#pragma omp simd reduction (+:s)
      for (PointDimension k = 0; k < d; ++k) {
        double t = x1[k] - x2[k];
        s += t*t;
      }
    return std::exp(-s);
  }

  virtual Double scaling_factor() const {
    return sqrtl(2.0L)/2.0L;
  }
};


//-------------- exp
class Correxp : public CorrelationFunction {
public:
  Correxp(const PointDimension d) :
  CorrelationFunction(d)  {
  }

  virtual double corr(const ScaledPoint& x1, const ScaledPoint& x2) const noexcept {
    double s = 0.;
	  //#pragma omp simd  reduction (+:s)
    for (PointDimension k = 0; k < d; ++k) s += std::fabs(x1[k] - x2[k]);
    return(std::exp(-s));
  }

  virtual Double scaling_factor() const {
    return 1.0L;
  }
};

//-------------- Matern32
class CorrMatern32 : public CorrelationFunction {
public:
  CorrMatern32(const PointDimension d) : CorrelationFunction(d)  {
  }

  virtual double corr(const ScaledPoint& x1, const ScaledPoint& x2) const noexcept {
    double s = 0.;
    double ecart = 0.;
    double prod = 1.;
    for (PointDimension k = 0; k < d; ++k) {
      ecart = std::fabs(x1[k] - x2[k]);
      s += ecart;
      prod *= (1.+ecart);
    }
    return(prod*std::exp(-s));
  }

  virtual Double scaling_factor() const {
    return sqrtl(3.0L);
  }
};

//-------------- Matern52
class CorrMatern52 : public CorrelationFunction {

public:
  CorrMatern52(const PointDimension d) : CorrelationFunction(d)  {
  }

  virtual double corr(const ScaledPoint& x1, const ScaledPoint& x2) const noexcept {
    double s = 0.;
    double ecart = 0.;
    double prod = 1.;
    for (PointDimension k = 0; k < d; ++k) {
      ecart = std::fabs(x1[k] - x2[k]);
      s += ecart;
      prod *= (1+ecart+ecart*ecart*TIERS);
    }
    return(prod*std::exp(-s));
  }

  virtual Double scaling_factor() const {
    return sqrtl(5.0L);
  }
};

//-------------- Powerexp
class CorrPowerexp : public CorrelationFunction {
public:
  const arma::vec& param;

  CorrPowerexp(const PointDimension d, const arma::vec& param) :
    CorrelationFunction(d), param(param)  {
  }

  virtual double corr(const ScaledPoint& x1, const ScaledPoint& x2) const noexcept {
    double s = 0.;
    for (PointDimension k = 0; k < d; ++k) s += std::pow(std::fabs(x1[k] - x2[k]) / param[k], param[k+d]);
    return(std::exp(-s));
  }

  virtual Double scaling_factor() const {
    return 1.0L;
  }
};

//========================================================== ChosenKernel
// chosen Kernel
// contains a link to chosen correlation function, and kernel parameters
// allows creating cross correlations matrix between vectors of points

class ChosenKernel {

  const PointDimension d;
  const arma::vec param; //no &, copy to make kernel independent
  const double var;
  const CorrelationFunction* chosenCorrFunction;

private:

  void setCorrelationFunction(std::string& covType) {
    if (covType.compare("gauss")==0) {chosenCorrFunction=new CorrGauss(d);}
    else if (covType.compare("exp")==0) {chosenCorrFunction=new Correxp(d);}
    else if (covType.compare("matern3_2") == 0) {chosenCorrFunction=new CorrMatern32(d);}
    else if (covType.compare("matern5_2") == 0) {chosenCorrFunction=new CorrMatern52(d);}
    else if (covType.compare("powexp") == 0) {chosenCorrFunction=new CorrPowerexp(d, param);}
    else if (covType.compare("white_noise") == 0) {chosenCorrFunction=new CorrWhiteNoise(d);}
    else {
      screen.warning("covType wrongly written, using exponential kernel");
      chosenCorrFunction=new Correxp(d);}
  }

public:

  ChosenKernel(const PointDimension d, const arma::vec& param, const double var, std::string covType) :
  d(d), param(param), var(var) {
    setCorrelationFunction(covType);
  }

  ~ChosenKernel() {
    delete chosenCorrFunction;
  }

  double getScalingFactor() const {
    return chosenCorrFunction->scaling_factor();
  }

  arma::vec getParam() const {
    return param;
  }

  void fillCorrMatrix(arma::mat& matrixToFill, const ScaledPoints& points) const {
    matrixToFill.set_size(points.size(),points.size());
    for (Long i = 0; i < points.size(); ++i) matrixToFill.at(i,i) = 1.0;
    for (Long i = 0; i < points.size(); ++i) // parallelizable
      for (Long j = 0; j < i; ++j)
        matrixToFill.at(i,j) = matrixToFill.at(j,i) = chosenCorrFunction->corr(points[i], points[j]);
  }

  void fillCrossCorrelations(arma::mat& matrixToFill, const ScaledPoints& pointsA, const ScaledPoints& pointsB) const {
    matrixToFill.set_size(pointsA.size(),pointsB.size());
    //#pragma omp parallel for schedule(static, 100) collapse(2)  //num_threads(4) //CHANTIER
    for (Long i = 0; i < pointsA.size(); ++i) // parallelizable
        for (Long j = 0; j < pointsB.size(); ++j)
          matrixToFill.at(i,j) = chosenCorrFunction->corr(pointsA[i], pointsB[j]);
 }

};

//========================================================== DATA SCALER
// scale an initial Data in order to apply a kernel with unit lengthscale

class DataScaler {
private:
  const ChosenKernel& chosenKernel;
  ScaledParameters scaledParam;
  const Long d;
  arma::rowvec origin;

  void createScaledParam(const arma::vec& param) {
    Double scalingFactor = chosenKernel.getScalingFactor();
    scaledParam.resize(d);
    //#pragma omp simd
    for(PointDimension k=0;k<d;++k) scaledParam[k] = param(k)/scalingFactor;
  }

public:

  DataScaler(const ChosenKernel& chosenKernel) : chosenKernel(chosenKernel), d(chosenKernel.getParam().n_rows), origin(arma::zeros<arma::rowvec>(d)) {
    createScaledParam(chosenKernel.getParam());
  }

  void setOrigin(const arma::rowvec& center) {
    origin=center;
  }

  void setLineToZero(ScaledPoints& scaledPoints, Long line) const {
    for(PointDimension k=0;k<d;++k) MatrixView<ScaledPoints>(scaledPoints).setValue(line, k, 0.0);
  }

  void fillScaledData(const arma::mat& source, ScaledPoints& scaledData) const {
    const Long nrows= source.n_rows;
    const PointDimension d= source.n_cols;
    MatrixView<ScaledPoints>(scaledData).allocate(nrows, d);
    for(Long obs=0;obs<nrows;++obs) { // parallelizable
      for(PointDimension k=0;k<d;++k)
        MatrixView<ScaledPoints>(scaledData).setValue(obs,k,(source.at(obs,k)-origin.at(k))/scaledParam[k]);
    }
  }
};

//======================================================= SCALED DATA
// initial data (design X, observations Y, prediction points x)
// with changed scaled, in order to apply unit lengthscales covariances
// also centered around the coordinate with origin x[0]
// => further substractions of 0.0 and differences calculated with higher precision

class ScaledData {

private:
  DataScaler dataScaler;

public:
  const PointDimension d;
  const Long n;
  const Long q;
  const arma::vec& Y;
  ScaledPoints designPoints;
  ScaledPoints predictionPoints;

  ScaledData(PointDimension d, const arma::mat& X, const arma::mat& x, const arma::vec& Y, const ChosenKernel& chosenKernel)
    : dataScaler(chosenKernel), d(d), n(X.n_rows), q(x.n_rows), Y(Y) {
    dataScaler.setOrigin(x.row(0));
    dataScaler.fillScaledData(X,designPoints);
    dataScaler.fillScaledData(x,predictionPoints);
    dataScaler.setLineToZero(predictionPoints,0);
  }
};

//========================================================== Ranks
// tool for getting the ranks of values in a container of nonnegative integers
// ranks are starting at zero

template <class VectorType>
class Ranks {
  const VectorType& values;
  std::vector<Long> rankByValue, count_ByRank, count_ByValue;

  Long maxValue(const VectorType& v) const {
    return *std::max_element(v.begin(),v.end());
  }

  void countOccurrencesByValue() {
    Long Nmax=maxValue(values)+1;
    count_ByValue.resize(Nmax,0);
    for(Long obs=0; obs<values.size(); ++obs) ++count_ByValue[values[obs]];
  }

  void computeRanks() {
    //find rank of each existing value, and compute the size by rank
    Long Nmax= count_ByValue.size();
    rankByValue.resize(Nmax, 0);
    count_ByRank.resize(Nmax, 0);
    Long rank=0;
    for(Long i=0; i<Nmax; ++i)
      if (count_ByValue[i]>0) {
        rankByValue[i]=rank;
        count_ByRank[rank]=count_ByValue[i];
        ++rank;
      }
      count_ByRank.resize(rank);
  }

public:
  Ranks(const VectorType& values) : values(values) {
    countOccurrencesByValue();
    computeRanks();
  }

  Long countDistinctValues() {
    return count_ByRank.size();
  }

  Long rankOf(Long value) const {
    return rankByValue[value];
  }

  Long countByRank(Long rank) const {
    return count_ByRank[rank];
  }
};
//========================================================== Splitter
// Tool for splitting a container into a vector of smaller containers (and remerging back)

class Splitter {
  // spitScheme vector gives a group number by observation. group number is typically in {0, ..., N-1}
  // group number is replaced by group rank, so that empty group numbers are allowed
protected:
  Long N; // number of non-empty groups
  Long n; // number of observations = splitscheme.size()
  std::vector<std::vector<Long> > obsByGroup;
  std::vector<Long> groupSize;

private:

  template <class VectorType>
  void setSplitScheme(const VectorType& splitScheme) {
    Ranks<VectorType> ranks(splitScheme);
    n = splitScheme.size();
    N = ranks.countDistinctValues();

    obsByGroup.clear();
    obsByGroup.resize(N);
    groupSize.resize(N);
    for(Long i=0; i<N; ++i) {
      groupSize[i] = ranks.countByRank(i);
      obsByGroup[i].reserve(groupSize[i]); //tight allocation
    }
    for(Long obs=0; obs<n; ++obs)
      obsByGroup[ranks.rankOf(splitScheme[obs])].push_back(obs);
  }

public:

  Splitter() : N(0), n(0) {}

  explicit Splitter(const std::vector<Long>& splitScheme) {
    setSplitScheme<std::vector<Long> >(splitScheme);
  }

  explicit Splitter(const arma::vec& splitScheme) {
    setSplitScheme<arma::vec>(splitScheme);
  }

  void setModuloSplitScheme(Long n, Long numberOfGroups) {
    std::vector<Long> splitScheme(n);
    for(Long obs=0; obs<n; ++obs) splitScheme[obs]=obs%numberOfGroups;
    setSplitScheme(splitScheme);
  }

  Long get_N() const {
    return N;
  }

  Long get_maxGroupSize() const {
    return *std::max_element(groupSize.begin(),groupSize.end());
  }

  template <class ContainerType>
  void split(const ContainerType& source,  std::vector<ContainerType>& splittedOutput) const {
    Long n_cols = MatrixView<const ContainerType>(source).ncols();
    splittedOutput.resize(N);
    for(Long i=0; i<N; ++i)
      MatrixView<ContainerType>(splittedOutput[i]).allocate(groupSize[i], n_cols);
    for(Long i=0; i<N; ++i)
      for(Long r=0; r<groupSize[i]; ++r)
        MatrixView<ContainerType>::identifyLines(splittedOutput[i], r, source, obsByGroup[i][r]);
  }

  template <class MatrixType>
  void splitMat(const MatrixType& source,  std::vector<MatrixType>& splittedOutput) const {
    split<MatrixType>(source,  splittedOutput);
  }

  template <class ContainerType>
  void merge(const std::vector<ContainerType>& splittedSource, ContainerType& mergedOutput) const {
    Long n_cols = MatrixView<const ContainerType>(splittedSource[0]).ncols();
    MatrixView<ContainerType>(mergedOutput).allocate(n, n_cols);
    for(Long i=0; i<N; ++i)
      for(Long r=0; r<groupSize[i]; ++r)
        MatrixView<ContainerType>::identifyLines(mergedOutput, obsByGroup[i][r], splittedSource[i], r);
  }

  template <class MatrixType>
  void mergeMat(const std::vector<MatrixType>& splittedSource, MatrixType& mergedOutput, Long ncols=1) {
    merge<MatrixType>(splittedSource, mergedOutput);
  }
};

//========================================================== Splitted DATA
// split a scaled data according to given groups gp[i]. Groups are given by splitter.

struct SplittedData {
  const ScaledPoints predictionPoints; //no ScaledPoints& => copy to make SplittedData indep from X,x,Y,gp
  std::vector<ScaledPoints> splittedX;
  std::vector<arma::rowvec> splittedY;
  const Long N;
  const Long cmax;

  SplittedData(const ScaledData& data, const Splitter& splitter)
    :  predictionPoints(data.predictionPoints), N(splitter.get_N()), cmax(splitter.get_maxGroupSize())  {
    splitter.split<ScaledPoints>(data.designPoints, splittedX);
    splitter.split<arma::rowvec>(data.Y.t(), splittedY);
  }
};

//============================== Linear Solvers
// choice of solver for linear systems (e.g. Cholesky / Inversion of Cov matrix / linear solver)
// please choose by setting: typedef (YourChosenClass) ChosenSolver;
// solve matrix equation K * alpha = k in alpha

class LinearSolver_InvSympd {
public:
  void findWeights(const arma::mat& K, const arma::mat& k, arma::mat& alpha) const {
    Long sizeK = K.n_rows;
    arma::mat Kinv(sizeK,sizeK);
    inv_sympd(Kinv,K);
    alpha = Kinv * k;
  }
};

class LinearSolver_Cholesky  {
public:
  void findWeights(const arma::mat& K, const arma::mat& k, arma::mat& alpha) const {
    arma::mat R = chol(K);
    arma::mat z = arma::solve(arma::trimatl(R.t()), k, arma::solve_opts::fast);
    alpha = arma::solve(arma::trimatu(R),z, arma::solve_opts::fast);
  }
};
class LinearSolver_Solve  {
public:
  void findWeights(const arma::mat& K, const arma::mat& k, arma::mat& alpha) const {
        alpha.set_size(K.n_rows,k.n_cols);
        arma::solve(alpha, K, k, arma::solve_opts::fast);
  }
};

typedef LinearSolver_Solve ChosenSolver;
//typedef LinearSolver_InvSympd ChosenSolver;

//============================================================================
// Kriging predictors: from covariances (K, k) and observations Y
// gives weights alpha, Yhat, Cov(Y, Yhat), Cov(Yhat, Yhat)

class KrigingPredictor{
protected:
const arma::mat& K;
const arma::mat& k;
const arma::mat& Y;
const Long q;

public:
  KrigingPredictor(const arma::mat& K, const arma::mat& k, const arma::mat& Y) : K(K), k(k), Y(Y), q(k.n_cols) {}
  virtual ~KrigingPredictor() {}

  virtual void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) const=0;
};

class SimpleKrigingPredictor : public KrigingPredictor {
public:
  SimpleKrigingPredictor(const arma::mat& K, const arma::mat& k, const arma::mat& Y): KrigingPredictor(K, k, Y) {
 }

  virtual void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) const {
    const ChosenSolver solver=ChosenSolver();
    solver.findWeights(K, k, weights);
    predictor = Y * weights;
		for(Long m=0;m<q;++m){ // parallelizable
        covYhatYhat[m] = covYhatY[m] = as_scalar( k.col(m).t() * weights.col(m) );
			}
  }
};

class OrdinaryKrigingPredictor : public KrigingPredictor {
public:
  const arma::mat kt;

  OrdinaryKrigingPredictor(const arma::mat& K, const arma::mat& k, const arma::mat& Y): KrigingPredictor(K,k,Y), kt(k.t()) {
  }

  virtual void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) const {
    Long sizeK = K.n_rows;
    arma::mat Kinv(sizeK,sizeK);
    inv_sympd(Kinv,K);
    arma::rowvec one_t(sizeK);
    one_t.ones();
    arma::rowvec tmp1 = (1-one_t*Kinv*k)/arma::accu(Kinv);

    arma::mat k_OK(sizeK,q);
    for(Long m=0;m<q;++m) k_OK.col(m) = k.col(m) + tmp1(m);
    weights = Kinv*k_OK;
    predictor = Y * weights;

    arma::mat kt_OK =  k_OK.t();
    for(Long m=0;m<q;m++){ // (*)
      covYhatY[m] = as_scalar( kt.row(m) * weights.col(m) );
      covYhatYhat[m] = as_scalar( kt_OK.row(m) * weights.col(m) );
    }
  }
};

class ChosenPredictor {
  KrigingPredictor* krigingPredictor;

public:
  ChosenPredictor(const arma::mat& K, const arma::mat& k, const arma::mat& Y, bool ordinaryKriging) {
    if (ordinaryKriging) {krigingPredictor=new OrdinaryKrigingPredictor(K, k, Y); }
    else {krigingPredictor=new SimpleKrigingPredictor(K, k, Y); }
  }

  ~ChosenPredictor() {
    delete krigingPredictor;
  }

  void fillResults(arma::mat& weights, arma::rowvec& predictor, std::vector<double>& covYhatY, std::vector<double>& covYhatYhat) {
    krigingPredictor->fillResults(weights,predictor,covYhatY,covYhatYhat);
  }
};


//========================================================================= output
class Output{

  template <class T>
  T empty(const T& object) const {
    T emptyObject;
    return emptyObject;
  }

public:
  std::vector<double> durations;
  double totalChrono;
  std::vector<arma::mat> Knu;   // q items, each = NxN cov matrix between Mi(x)
  std::vector<arma::vec> knu;   // q items, each = Nx1 cov vector between Mi(x) and Y(x)
  std::vector<arma::vec> Yhat;  // q items, each = Nx1 prediction vector Mi(x)
  std::vector<arma::mat> alpha; // N items, each = ni x q matrix of weights: columns give weigths for each pred point in the submodel
  arma::mat weights;            // q columns, each = Nx1 weigts between submodels (N x q matrix)
  arma::vec predmean;           // q x 1 prediction vector, pred mean for each pred point
  arma::vec predsd2;            // q x 1 prediction vector, pred var  for each pred point

  // replace enum class which cannot be used as integer template argument without cast
  struct Durations {enum durationParts { partA=0, partB=1, partC=2, total=3}; };

  Output(Long N, Long q) : durations(4, 0.0), totalChrono(0), Knu(q), knu(q), Yhat(q), alpha(N), weights(N,q), predmean(q), predsd2(q) {
    reserveMatrices(N,q);
  }

  Output() :  durations(4, 0.0), totalChrono(0) {}

  void reserveMatrices(Long N, Long q) {
    predmean.resize(q);
    predsd2.resize(q);
    weights.set_size(N,q);
    Knu.resize(q);
    knu.resize(q);
    Yhat.resize(q);
    for(Long m=0; m<q; ++m) {
      knu[m].set_size(N);
      Yhat[m].set_size(N);
      Knu[m].set_size(N,N);
    }
  }
  //copy constructor and affectation operators are used after, they are set to default's compiler ones

  Rcpp::List exportList(int outputDetailLevel=2) const {
    std::ostringstream versionInfos;
    versionInfos << VERSION_CODE;
    versionInfos << " built ";
    versionInfos << BUILT_ID;
    return Rcpp::List::create(Rcpp::Named("mean") = predmean,
                              Rcpp::Named("sd2") = predsd2,
                              Rcpp::Named("duration_PartA") = durations[Durations::partA],
                              Rcpp::Named("duration_PartB") = durations[Durations::partB],
                              Rcpp::Named("duration_PartC") = durations[Durations::partC],
                              Rcpp::Named("duration_ABC")   = durations[Durations::total],
                              Rcpp::Named("duration_Total") = totalChrono,
                              Rcpp::Named("sourceCode") = versionInfos.str(),
                              Rcpp::Named("weights") = (outputDetailLevel>=1)?weights:empty(weights),
                              Rcpp::Named("Yhat") = (outputDetailLevel>=1)?Yhat:empty(Yhat),
                              Rcpp::Named("K_M") = (outputDetailLevel>=2)?Knu:empty(Knu),
                              Rcpp::Named("k_M") = (outputDetailLevel>=2)?knu:empty(knu));
  }
};


//================================================================================== Algo
// Algorithm with only one layer

class Algo {

  //input objects (cf. end of the unit for a description)
  const Parallelism& parallelism;

  const PointDimension d;
  const double sd2;
  const bool ordinaryKriging;
  std::string tag;
  const int verboseLevel;

  //built in construction
  const ChosenKernel kernel;
  //const ScaledData data;
  const SplittedData splittedData;
  const Long n, q, N;
  Chrono chrono;

  //results of the algorithm
  Output out;

  template <int ShowProgress>
  void run() {
    chrono.start();
    firstLayer_partA<ShowProgress>();
    out.durations[Output::Durations::partA] = chrono.durationStep();
    firstLayer_partB<ShowProgress>();
    out.durations[Output::Durations::partB] = chrono.durationStep();
    agregateFirstLayer<ShowProgress>();
    out.durations[Output::Durations::partC] = chrono.durationStep();
    out.durations[Output::Durations::total] = chrono.durationSinceStart();
  }

public:
  Algo(const Parallelism& parallelism, const arma::mat& X, const arma::vec& Y, const Splitter& splitter, const arma::mat& x, const arma::vec& param,
       const double sd2, const bool ordinaryKriging, const std::string covType, std::string tag="", const int verboseLevel=10)
    : parallelism(parallelism), d(X.n_cols), sd2(sd2), ordinaryKriging(ordinaryKriging),
      verboseLevel(verboseLevel), kernel(d, param, 1.0, covType), //data(d, X, x, Y, kernel),
      splittedData(ScaledData(d, X, x, Y, kernel), splitter), n(X.n_rows), q(x.n_rows), N(splittedData.N), chrono(tag), out(N,q)
  { constexpr int showProgress=1, noShowProgress=0;
    if (verboseLevel>0) run<showProgress>();
    else run<noShowProgress>();
  }

template <int ShowProgress>
void firstLayer_partA() {
    chrono.print("Part A, first layer, prediction for each group: starting...");
    ProgressBar<ShowProgress> progressBar(chrono, N, verboseLevel);
    parallelism.switchToContext<Parallelism::innerContext>();
    #pragma omp parallel for schedule(SCHEDULE, CHUNKSIZE)// Main label (A)
    for(Long i=0; i<N; ++i) {

      arma::mat K, k;
      kernel.fillCorrMatrix(K, splittedData.splittedX[i]); //size of K: ni x ni
      kernel.fillCrossCorrelations(k, splittedData.splittedX[i], splittedData.predictionPoints); //size of k: ni x q
		  ChosenPredictor krigingPredictor(K, k, splittedData.splittedY[i], ordinaryKriging);
		  arma::rowvec vec_Yhat(q);
		  std::vector<double> covYhatY(q);
		  std::vector<double> covYhatYhat(q);

		  krigingPredictor.fillResults(out.alpha[i], vec_Yhat, covYhatY, covYhatYhat);

      for(Long m=0;m<q;++m){ // parallelizable
        out.Yhat[m](i) = vec_Yhat[m];
        out.knu[m](i) =covYhatY[m];
        out.Knu[m](i,i) = covYhatYhat[m];
      }
      progressBar.next();
    }
    chrono.print("Part A, first layer, prediction for each group: done.");
  }

template <int ShowProgress>
void firstLayer_partB_v0() {
  const Long wmax=N*(N-1)/2;
  chrono.print("Part B, first layer, covariances inter-groups: starting...");
  ProgressBar<ShowProgress> progressBar(chrono, wmax, verboseLevel);
  parallelism.switchToContext<Parallelism::innerContext>();
#pragma omp parallel for schedule(SCHEDULE, CHUNKSIZE) collapse(2)
  for(Long i=0; i<N; ++i)
    for(Long j=0; j<N; ++j) {
      if (i<j) {
        arma::mat Kij;
        //parallelism.switchToContext<Parallelism::residualContext>(); //CHANTIER
        kernel.fillCrossCorrelations(Kij, splittedData.splittedX[i], splittedData.splittedX[j]);
        arma::mat Mi =  Kij * out.alpha[j];
        //#pragma omp parallel for schedule(static, 1) // CHANTIER
        for(Long m=0;m<q;++m) out.Knu[m].at(i,j) = out.Knu[m].at(j,i) = arma::dot(out.alpha[i].col(m), Mi.col(m));
        progressBar.next();
      }
    }
    chrono.print("Part B, first layer, covariances inter-groups: done.");
}


template <int ShowProgress>
  void firstLayer_partB() {
    long choixImplementation=globalOptions.getOptionValue(GlobalOptions::Option::implAlgoB);
    switch (choixImplementation)  {
    default:
      firstLayer_partB_v0<ShowProgress>(); break;
    }
  }

  template <int ShowProgress>
  void agregateFirstLayer() {
    chrono.print("Part C, aggregation first layer: starting...");
    LinearSolver_Solve solver;
    parallelism.switchToContext<Parallelism::innerContext>(); //A peaufiner car NbThreads limités par N
    #pragma omp parallel for schedule(SCHEDULE, CHUNKSIZE)// Main label (C)
    for(Long m = 0; m < q; ++m) {
      arma::mat alpha(N,1);
        solver.findWeights(out.Knu[m], out.knu[m], alpha);
      out.weights.col(m) = alpha;
      out.predmean(m) = as_scalar( alpha.t() * out.Yhat[m] );
      out.predsd2(m) = std::max(0. , sd2* (1 - as_scalar(alpha.t() * out.knu[m])));
    }
    chrono.print("Part C, aggregation first layer: done.");
  }

  Output output() const {
    return out;
  }

  Rcpp::List exportList(int outputDetailLevel=0) const {
    return out.exportList(outputDetailLevel);
  }

};
//======================= Launch independent algorithms on separate prediction zones

class AlgoZones {

  // algo inputs
  const Parallelism& parallelism;
  const arma::mat &X, &x;
  const arma::vec &Y, &param;
  const Splitter& splitter;
  const bool ordinaryKriging;
  const std::string covType;
  const Long NbZones, n, q;
  const PointDimension d;
  const double sd2;
  const std::string tagAlgo;
  const int verboseLevel;
  const int outputDetailLevel;

  // splitted objects
  Splitter splitterZone;
  std::vector<arma::mat> splittedx;
  std::vector<Output> splittedOutput;
  Output mergedOutput;

  Chrono chrono;

  void updateDurations() {
    for(int part=0; part<= Output::Durations::total; ++part) {
      double maxDuration=0.0;
      for(Long z=0; z<NbZones; ++z) maxDuration = std::max(maxDuration, splittedOutput[z].durations[part]);
      mergedOutput.durations[part]=maxDuration;
    }
    mergedOutput.totalChrono = chrono.durationSinceStart();
  }

  void mergeOutputs(const Splitter& splitterZone) {
    chrono.print("merge outputs: starting...");
    std::vector<arma::vec> splittedpredmean(NbZones), splittedpredsd2(NbZones);
    std::vector<std::vector<arma::vec> > splittedknu(NbZones), splittedYhat(NbZones);
    std::vector<std::vector<arma::mat> > splittedKnu(NbZones);
    for(Long i=0; i<NbZones; ++i) {
      splittedpredmean[i] = splittedOutput[i].predmean;
      splittedpredsd2[i] = splittedOutput[i].predsd2;
      if (outputDetailLevel>=1) splittedYhat[i]= splittedOutput[i].Yhat;
      if (outputDetailLevel>=2) splittedknu[i] = splittedOutput[i].knu;
      if (outputDetailLevel>=2) splittedKnu[i] = splittedOutput[i].Knu;
    }
    splitterZone.merge<arma::vec>(splittedpredmean, mergedOutput.predmean);
    splitterZone.merge<arma::vec>(splittedpredsd2, mergedOutput.predsd2);
    if (outputDetailLevel>=1) splitterZone.merge<std::vector<arma::vec> >(splittedYhat, mergedOutput.Yhat);
    if (outputDetailLevel>=2) splitterZone.merge<std::vector<arma::vec> >(splittedknu, mergedOutput.knu);
    if (outputDetailLevel>=2) splitterZone.merge<std::vector<arma::mat> >(splittedKnu, mergedOutput.Knu);

    chrono.print("merge outputs: done.");
  }

public:
  AlgoZones(Parallelism& parallelism, Long NbZones, const arma::mat& X, const arma::vec& Y, const Splitter& splitter, const arma::mat& x, const arma::vec& param,
            const double sd2, const bool ordinaryKriging, const std::string covType, const std::string tagAlgo="", const int verboseLevel=10, const int outputDetailLevel=0)
    :  parallelism(parallelism), X(X), x(x), Y(Y), param(param), splitter(splitter), ordinaryKriging(ordinaryKriging), covType(covType),
       NbZones(NbZones), n(X.n_rows), q(x.n_rows), d(X.n_cols), sd2(sd2), tagAlgo(tagAlgo), verboseLevel(verboseLevel), outputDetailLevel(outputDetailLevel),
       chrono("general zone")
       {
    run();
  }

  void run() {
    chrono.start();
    splitterZone.setModuloSplitScheme(q, NbZones);
    splitterZone.splitMat(x, splittedx);
    splittedOutput.resize(NbZones);
    // no preallocation of splittedoutput content, done with further affectations splittedOutput[z] =...
    parallelism.switchToContext<Parallelism::outerContext>();
    #pragma omp parallel for schedule(static, CHUNKSIZE)
    for(Long z=0; z<NbZones; ++z) {
        std::string tag = tagAlgo + " zone=" + std::to_string(z);
        Algo* algo=new Algo(parallelism, X, Y, splitter, splittedx[z], param, sd2, ordinaryKriging, covType, tag, verboseLevel);
        splittedOutput[z] = algo->output();
        delete algo;
        }
    mergeOutputs(splitterZone);
    updateDurations();
    chrono.print("finished.");
  }

  Output output() const {
    return mergedOutput;
  }

 Rcpp::List exportList(int outputDetailLevel=0) const {
   return mergedOutput.exportList(outputDetailLevel);
   }
};

Rcpp::List nested_kriging(
const arma::mat& X,
const arma::vec& Y,
const arma::vec& clusters,
const arma::mat& x,
const std::string covType,
const arma::vec& param,
const double sd2,
const bool ordinaryKriging=false,
const std::string tagAlgo="",
long numThreadsZones=0,
long numThreads=0,
const int verboseLevel=10,
const int outputDetailLevel=1,
Rcpp::IntegerVector optionsVector = Rcpp::IntegerVector::create(0)
) {

screen.showMessages = (verboseLevel>=1);
screen.showWarnings = (verboseLevel>=0);

globalOptions.set(optionsVector);
//globalOptions.print(tagAlgo);

Splitter splitter(clusters);
Long q=x.n_rows, N=splitter.get_N();

Parallelism::showInformations(tagAlgo);
Parallelism parallelism;
parallelism.setThreadsNumber<Parallelism::outerContext>(numThreadsZones);
parallelism.boundThreadsNumber<Parallelism::outerContext>(q);
parallelism.setThreadsNumber<Parallelism::innerContext>(numThreads);
Long maxThreadsGroup = std::max(N*(N-1)/2, static_cast<Long>(1));
parallelism.boundThreadsNumber<Parallelism::innerContext>(maxThreadsGroup);
parallelism.setThreadsNumber<Parallelism::residualContext>(globalOptions.getOptionValue(GlobalOptions::Option::numThreadsOther));



Long threadsZone=static_cast<Long>(numThreadsZones), threadsGroups=static_cast<Long>(numThreads);
if (threadsZone>q) screen.warning("as numThreadsZones>q, algorithm Zone will not use all available threads");
if (threadsGroups>N) screen.warning("as numThreads>N, algorithm (part A) will not use all available threads");
if (threadsGroups>maxThreadsGroup) screen.warning("as numThreads>N(N-1)/2, algorithm (part B) will not use all available threads");

const long NbZones = parallelism.getBoundedThreadsNumber<Parallelism::outerContext>();

if (NbZones>1) {
      AlgoZones algoZ(parallelism, NbZones, X, Y, splitter, x, param, sd2, ordinaryKriging, covType, tagAlgo, verboseLevel, outputDetailLevel);
      return algoZ.exportList(outputDetailLevel);
    } else {
      Algo algo(parallelism, X, Y, splitter, x, param, sd2, ordinaryKriging, covType, tagAlgo, verboseLevel);
      return algo.exportList(outputDetailLevel);
    }
}

}//end namespace
#endif /* NESTEDKRIGING_HPP */

// conventions for objects
// X: design matrix, n x d
// Y: response vector, size n
// clusters: vector containing the group number of all n points
// x: matrix of points where the prediction is computed: q x d
// covType: the covariance name
// param: vector of parameters of the considered covariance
// sd2: variance
// OrdinaryKriging: boolean, true= use Simple Kriging, false=use Ordinary Kriging
// tagAlgo: string displayed with messages, to identify algorithm run
// numThreadsZones: number of Threads among prediction points (should be <q, recommended= 1)
// numThreads: number of Threads among groups (shoud be <N)

// deduced parameters:
// gpsize: vector with the sizes of each group, deduced from gp
// N: total number of groups (no more used, deduced from gp)
// q: number of points where a prediction is computed = x.n_rows
// n: number of observations = X.n_rows
// d: dimension = X.n_cols = x.n_cols

// conventions for loop indexes
// obs = 0...n-1 , n number of observations
// k   = 0...d-1 , d dimension
// i   = 0...N-1 , N number of groups, first loop
// j   = 0...N-1 , N number of groups, second loop
// m   = 0...q-1 , q number of prediction points
// r   = 0...groupSize[i]-1, row/elt iterator in group i (class Splitter only)
// z   = 0...NbZones-1, zone iterator when prediction points x are splitted into NbZones zones
// w   = 0...N*N-1 , fuse of the two loops for i, for j

