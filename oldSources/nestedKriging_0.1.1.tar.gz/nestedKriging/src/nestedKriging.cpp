

#ifndef NESTEDKRIGING
#define NESTEDKRIGING

#include "nestedKriging.h"
#include "tests.h"
#include <vector>

using namespace nestedKrig;
using namespace nestedKrigTests;


//======================================================= CALL FROM R
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List versionInfo() {
#if defined(USECOMPACTSTORAGE)
  bool compactStorage = true;
#else
  bool compactStorage = false;
#endif
  return Rcpp::List::create(
    Rcpp::Named("versionCode") = VERSION_CODE,
    Rcpp::Named("built") = BUILT_ID,
    Rcpp::Named("interfaceVersion") = INTERFACE_VERSION,
    Rcpp::Named("interfacesDescription") = "nested_kriging(X, Y, clusters, x, covType, param, sd2, [krigingType, tagAlgo, numThreadsZones, numThreads, verboseLevel, outputLevel])",
    Rcpp::Named("compactSorage", compactStorage)
    );
}

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List nestedKrigingDirect(
const arma::mat& X,
const arma::vec& Y,
const arma::vec& clusters,
const arma::mat& x,
const std::string covType,
const arma::vec& param,
const double sd2,
const std::string krigingType="simple",
const std::string tagAlgo="",
const long numThreadsZones=1,
const long numThreads=16,
const int verboseLevel=10,
const int outputLevel=1,
Rcpp::IntegerVector optionsVector = Rcpp::IntegerVector::create(0)
)
{
// Rcpp seems not allowing export of default value for other arma or std vector, thus the use of IntegerVector
bool OrdinaryKriging = (krigingType=="ordinary");
return nested_kriging(X, Y, clusters, x, covType, param, sd2, OrdinaryKriging, tagAlgo, numThreadsZones, numThreads, verboseLevel, outputLevel, optionsVector);
}

//---------------------------------------------------------- Run All Tests

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List tests_run(bool showSuccess=false) {
  Test::testCounter = 0;
  Test test("all tests");
  //=== Part 0, test environment
  test.append(testPlatformIndependentRng());
  test.append(testPlatformIndependentCaseStudy());
  //=== Part I, Unit Tests
    test.append(testProgressBar());
    test.append(testKernelSym());
    test.append(testKernelGaussDimTwo());
    test.append(testRetrieveCorrFromCrossCorr());
    test.append(testKernelIdenticalNicolas());
    test.append(testRanks());
    test.append(testSplitterA());
    test.append(testSplitterB());
    test.append(testSplitterC());
    test.append(testSplitterD());

  //=== Part II Check Intermediate Results with Other Implementations
    test.append(testIdenticalYhatNicolasCase1());
    test.append(testIdenticalYhatNicolasCase2());
    test.append(testIdenticalYhatClement());
    test.append(testIdenticalYhatClementSmallLengthScales());
    test.append(testIdenticalYhatNicolasSmallLengthScales());
    test.append(testIdenticalCorrMatrixK());
    test.append(testIdenticalCrossCorrMatrixk());
    test.append(testIdenticalCorrMatrixKSmallLengthScales());
    test.append(testIdenticalCrossCorrMatrixkSmallLengthScales());
    test.append(testIdenticalWeightClement());
    test.append(testWeightsSolveSystem());

  //=== Part III Check Final Results - alone
    test.append(testOneDesignPointOnly());
    test.append(testPermutationHasNoImpact());
    test.append(testWithRotatedPredPoints());
    test.append(testInterpolating());
    test.append(testMultithreadCompilation());
    test.append(testMergeOutputInAlgoZone());
    test.append(testNoThreadImpact());
    test.append(testTooManyThreads());
    test.append(testIdenticalExtremeGroups());

  //=== Part IV Check Final Results - as other codes
    test.append(testIdenticalMeanSd2WithClement());
    test.append(testIdenticalMeanSd2WithClementSK());
    test.append(testIdenticalMeanSd2WithNicolasSKfocus1());
    test.append(testIdenticalMeanSd2WithNicolasSKfocus2());
    test.append(testIdenticalDiceKriging());
    test.append(testNoCriticalStopWithLargerData());

  test.printSummary(showSuccess);
  return Rcpp::List::create(Rcpp::Named("ok") = test.status());
}

//-------------------------------------------------- functions for manual tests and debugging
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List tests_getCodeValues(unsigned long selectedCase, std::string covType="gauss", bool forceSimpleKriging=false, double increaseParam=0.0) {
  Rcpp::List resu, resuCas2;
  std::ostringstream ossmean, osssd2;
  for(unsigned long i=1; i<10; ++i) {
    CaseStudy cas=CaseStudy(i, covType);
    if (forceSimpleKriging) cas.ordinaryKriging=false;
    cas.param= cas.param + increaseParam;
    resu=launchOurAlgo(cas);
    unsigned long pickx=cas.pickx;
    arma::vec algoAmean=resu["mean"];
    arma::vec algoAsd2=resu["sd2"];
    ossmean << std::setprecision(12) << algoAmean(pickx) << " ";
    osssd2 << std::setprecision(12) << algoAsd2(pickx) << " ";
    if (i==selectedCase) resuCas2=resu;
  }
  Screen myscreen;
  std::ostringstream oss;
  std::string sourceCode = resu["sourceCode"];
  oss << "our code: " ;
  oss << "[[[ values from code " << sourceCode << std::endl;
  oss << "mean: " << ossmean.str() << std::endl;
  oss << "sd2: " << osssd2.str() << std::endl;
  oss << "end code " << sourceCode << " ]]]" << std::endl;
  myscreen.print(oss);
  //std::cout << "essai" << std::endl;
  return resuCas2;
}

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List tests_getCaseStudy(unsigned long selectedCase, std::string covType="gauss") {
  CaseStudy mycase(selectedCase, covType);
  return mycase.output();
}

#endif /* NESTEDKRIGING */


//======================================= Deprecated, for compatibility only
// following lines for compatilibility with old implementations only:
/*
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List fast_pred(const arma::mat& X, const arma::vec& Y, const long n,  const PointDimension d,
    const arma::vec& gp, const arma::vec& gpsize, const long N, const arma::mat& x, const long q,
    const std::string covType, const arma::vec& param, const double sd2, const bool OrdinaryKriging=false,
    const std::string tagAlgo="", const long numThreadsZones=0, const long numThreads=0, const int verboseLevel=10)
  {
    return nested_kriging(X, Y, gp, x, covType, param, sd2, OrdinaryKriging, tagAlgo, numThreadsZones, numThreads, verboseLevel);
  }
*/

// conventions for loop indexes
// obs = 0...n-1 , n number of observations
// k   = 0...d-1 , d dimension
// i   = 0...N-1 , N number of groups, first loop
// j   = 0...N-1 , N number of groups, second loop
// m   = 0...q-1 , q number of prediction points
// r   = 0...groupSize[i]-1, row/elt iterator in group i (class Splitter only)
// z   = 0...NbZones-1, zone iterator when prediction points x are splitted into NbZones zones
