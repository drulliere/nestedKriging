
#ifndef COMMON_HPP
#define COMMON_HPP

//===============================================================================
// unit used for common requirements for all packages:
// contains Rcpp management, basic types and some configuration constants
//===============================================================================

#define VERSION_CODE "nestedKriging v0.1.3"
#define BUILT_ID 43
#define BUILT_DATE 20190315
#define INTERFACE_VERSION 6

//========================================================== R - Armadillo =======

#include <RcppArmadillo.h>

// [[Rcpp::plugins(openmp, cpp11)]]

using namespace Rcpp;
#define ARMA_NO_DEBUG //uncomment to avoids bounds check for Armadillo objects (1-2% faster)
//================================================================================

#include <vector> // std::vector

#if !defined(__FMA__) && defined(__AVX2__)
#define __FMA__ 1
#endif

namespace nestedKrig {

using PointDimension = std::size_t;
using Long = std::size_t ;

//ClusterVector: avoid unsigned long, as negative values would be casted to huge values
//furthermore, the program now allows negative clusters indexes
using ClusterVector = std::vector<long>;

//------------- end namespace
}
#endif /* COMMON_HPP */

